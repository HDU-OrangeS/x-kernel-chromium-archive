// SPDX-License-Identifier: Apache-2.0
// Copyright 2025 KylinSoft Co., Ltd. <https://www.kylinos.cn/>
// See LICENSES for license details.

//! Thread Local Storage (TLS) support.
//!
//! ## TLS layout for x86_64
//!
//! ```text
//! aligned --> +-------------------------+- static_tls_offset
//! allocation  |                         | \
//!             | .tdata                  |  |
//! | address   |                         |  |
//! | grow up   + - - - - - - - - - - - - +   > Static TLS block
//! v           |                         |  |  (length: static_tls_size)
//!             | .tbss                   |  |
//!             |                         |  |
//!             +-------------------------+  |
//!             | / PADDING / / / / / / / | /
//!             +-------------------------+
//!    tls_ptr -+-> self pointer (void *) | \
//! (tp_offset) |                         |  |
//!             | Custom TCB format       |   > Thread Control Block (TCB)
//!             | (might be used          |  |  (length: TCB_SIZE)
//!             |  by a libC)             |  |
//!             |                         | /
//!             +-------------------------+- (total length: tls_area_size)
//! ```
//!
//! ## TLS layout for AArch64 and RISC-V
//!
//! ```text
//!             +-------------------------+
//!             |                         | \
//!             | Custom TCB format       |  |
//!             | (might be used          |   > Thread Control Block (TCB)
//!             |  by a libC)             |  |  (length: TCB_SIZE)
//!             |                         | /
//!    tls_ptr -+-------------------------+
//! (tp_offset) | GAP_ABOVE_TP            |
//!             +-------------------------+- static_tls_offset
//!             |                         | \
//!             | .tdata                  |  |
//!             |                         |  |
//!             + - - - - - - - - - - - - +   > Static TLS block
//!             |                         |  |  (length: static_tls_size)
//!             | .tbss                   |  |
//!             |                         | /
//!             +-------------------------+- (total length: tls_area_size)
//! ```
//!
//! Reference:
//! 1. <https://github.com/unikraft/unikraft/blob/staging/arch/x86/x86_64/tls.c>
//! 2. <https://github.com/unikraft/unikraft/blob/staging/arch/arm/arm64/tls.c>

extern crate alloc;

use core::{alloc::Layout, ptr::NonNull};

use memaddr::align_up;

use crate::addr_of_sym;

const TLS_ALIGN: usize = 0x10;

cfg_if::cfg_if! {
    if #[cfg(target_arch = "x86_64")] {
        const TCB_SIZE: usize = 8; // to store TLS self pointer
        const GAP_ABOVE_TP: usize = 0;
    } else if #[cfg(target_arch = "aarch64")] {
        const TCB_SIZE: usize = 0;
        const GAP_ABOVE_TP: usize = 16;
    } else if #[cfg(target_arch = "riscv64")] {
        const TCB_SIZE: usize = 0;
        const GAP_ABOVE_TP: usize = 0;
    } else if #[cfg(target_arch = "loongarch64")] {
        const TCB_SIZE: usize = 0;
        const GAP_ABOVE_TP: usize = 0;
    }
}

unsafe extern "C" {
    fn _stdata();
    fn _etdata();
    fn _etbss();
}

/// The memory region for thread-local storage.
pub struct TlsArea {
    base: NonNull<u8>,
    layout: Layout,
}

impl Drop for TlsArea {
    fn drop(&mut self) {
        // SAFETY: `base` was allocated from the global allocator with exactly
        // `layout` in `TlsArea::alloc`, and `Drop` runs at most once.
        unsafe { alloc::alloc::dealloc(self.base.as_ptr(), self.layout) }
    }
}

impl TlsArea {
    /// Returns the pointer to the TLS static area.
    ///
    /// One should set the hardware thread pointer register to this value.
    pub fn tls_ptr(&self) -> *mut u8 {
        // SAFETY: `base` points to an allocation of `tls_area_size()` bytes,
        // and `tp_offset()` is defined to lie within that allocation for the
        // active architecture's TLS layout.
        unsafe { self.base.as_ptr().add(tp_offset()) }
    }

    /// Allocates the memory region for TLS, and initializes it.
    pub fn alloc() -> Self {
        let layout = Layout::from_size_align(tls_area_size(), TLS_ALIGN).unwrap();
        // SAFETY: `layout` was validated above. Allocation failure is handled
        // before any pointer arithmetic or initialization occurs.
        let area_base = unsafe { alloc::alloc::alloc_zeroed(layout) };
        let base =
            NonNull::new(area_base).unwrap_or_else(|| alloc::alloc::handle_alloc_error(layout));

        // SAFETY: `base` is a non-null allocation of `layout.size()` bytes.
        // The source `.tdata` range comes from linker-defined symbols, and the
        // destination static-TLS subrange lies within the TLS allocation.
        unsafe {
            let tls_load_base = _stdata as *mut u8;
            let tls_load_size = (_etdata as *mut u8).offset_from_unsigned(_stdata as *mut u8);
            // copy data from .tbdata section
            core::ptr::copy_nonoverlapping(
                tls_load_base,
                base.as_ptr().add(static_tls_offset()),
                tls_load_size,
            );
            // initialize TCB
            init_tcb(base);
        }

        Self { base, layout }
    }
}

fn static_tls_size() -> usize {
    align_up(addr_of_sym!(_etbss) - addr_of_sym!(_stdata), TLS_ALIGN)
}

fn static_tls_offset() -> usize {
    if cfg!(target_arch = "x86_64") {
        0
    } else if cfg!(any(
        target_arch = "aarch64",
        target_arch = "riscv64",
        target_arch = "loongarch64"
    )) {
        TCB_SIZE + GAP_ABOVE_TP
    } else {
        unreachable!()
    }
}

fn tp_offset() -> usize {
    if cfg!(target_arch = "x86_64") {
        static_tls_size()
    } else if cfg!(any(
        target_arch = "aarch64",
        target_arch = "riscv64",
        target_arch = "loongarch64"
    )) {
        TCB_SIZE
    } else {
        unreachable!()
    }
}

fn tls_area_size() -> usize {
    if cfg!(target_arch = "x86_64") {
        static_tls_size() + TCB_SIZE
    } else if cfg!(any(
        target_arch = "aarch64",
        target_arch = "riscv64",
        target_arch = "loongarch64"
    )) {
        TCB_SIZE + GAP_ABOVE_TP + static_tls_size()
    } else {
        unreachable!()
    }
}

fn init_tcb(tls_area: NonNull<u8>) {
    if cfg!(target_arch = "x86_64") {
        // SAFETY: `tls_area` is the base of the newly allocated TLS region,
        // and on x86_64 the TCB self-pointer slot lives at `tp_offset()`
        // within that allocation.
        unsafe {
            let tp_addr = tls_area.as_ptr().add(tp_offset()).cast::<usize>();
            tp_addr.write(tp_addr as usize); // write self pointer
        }
    }
}

#[cfg(all(unittest, feature = "tls"))]
#[allow(missing_docs)]
pub mod tests_tls {
    use unittest::def_test;

    use super::TlsArea;

    #[def_test]
    fn test_tls_alloc_ptr_non_null() {
        let area = TlsArea::alloc();
        let ptr = area.tls_ptr();
        assert!(!ptr.is_null());
    }

    #[cfg(target_arch = "x86_64")]
    #[def_test]
    fn test_tls_self_pointer_x86_64() {
        let area = TlsArea::alloc();
        let ptr = area.tls_ptr();
        let stored = unsafe { *(ptr as *const usize) };
        assert_eq!(stored, ptr as usize);
    }
}
