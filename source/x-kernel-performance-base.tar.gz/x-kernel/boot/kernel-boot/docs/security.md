# kernel-boot — AArch64 MMU/cache-control safety

## Scope and trust boundary

This analysis covers the AArch64 `init_mmu` cache-access policy and its primary
and secondary callers. It does not claim a complete security audit of every
architecture entry implementation in this crate.

The boot layer trusts firmware/entry state, linker-resolved image locations,
prepared page tables and the CPU register model. Runtime userspace is untrusted.
`init_mmu` sets a CPU-wide EL0 access policy before userspace runs; it does not
accept a user pointer, parse a syscall request, touch DMA or traverse a runtime
filesystem. Its existing boot tables map the image, boot console and required
RAM/DTB ranges; those mappings remain a separate boot safety boundary.

## Unsafe and ordering invariants

`src/arch/aarch64/mmu.rs::init_mmu` is an unsafe boot entry helper because the
caller must guarantee that enabling the MMU preserves the executing code,
stack and required data and that both page-table roots are initialized.
The primary and secondary assembly entries call it after their exception-level
setup. The new UCT/UCI fields use the existing typed `SCTLR_EL1.modify` API;
there is no new inline assembly, raw pointer access or unsafe block.

Register state is CPU-local. The common entry path updates both primary and
secondary CPUs; it does not add concurrent writes to shared page-table storage.
The existing ISB after SCTLR writes synchronizes subsequent instruction execution
with the new control state. Do not move the user-access controls after the first
EL0 entry or update only the bootstrap CPU.

## Access granted and residual limits

`UCT=1` permits direct reading of the implemented `CTR_EL0` value in the ordinary
EL1/EL0 regime. `UCI=1` removes the SCTLR trap on specified AArch64 EL0 cache
maintenance operations. This is an intentional userspace capability needed by
normal generated-code runtimes; it is not permission to execute arbitrary EL1
instructions. The change does not add writable/executable mappings, relax page
table access bits, expose a kernel memory-copy API, or alter exception-to-signal
classification. Translation/access faults and other architectural or hypervisor
trap controls remain separate from these two SCTLR bits.

Direct CTR reads expose the CPU's cache characteristics. Cache operations can
affect timing and contention; no new side-channel isolation guarantee is made.
On heterogeneous CPUs, direct reads alone do not construct a safe system-wide
cache description. A platform needing that contract must implement and validate
an appropriate trap/emulation policy instead of relying on this homogeneous
QEMU configuration. The VHE path is outside this fix's demonstrated test scope.

## Failure analysis

| Failure | Trigger and effect | Control / remaining limitation |
|---|---|---|
| Valid user cache instructions become SIGILL | Firmware/reset leaves UCT/UCI disabled; a runtime reads CTR or performs cache maintenance | Explicitly set both fields in the per-CPU boot path; validate the same instructions from EL0. |
| Failure depends on CPU placement | Only one CPU receives the access policy | Both entry paths call the shared `init_mmu`; test coverage on a single CPU alone does not prove migration behavior. |
| Boot loses mappings or control ordering | Invalid boot roots or altered enable sequence | Preserve the existing root initialization/caller contracts and post-SCTLR ISB; no MMU handoff refactor is part of this fix. |
| Probe success is mistaken for JIT correctness | Permissions work while publication, barriers or VM behavior remain wrong | Keep instruction-permission tests separate from browser and cross-CPU consistency validation. |

The fix adds no logging, collected user data or persistent diagnostic resource.
Reviewers should preserve unrelated SCTLR bits, use named fields instead of
numeric masks for this policy, and keep genuine undefined-instruction delivery
working in regression tests.
