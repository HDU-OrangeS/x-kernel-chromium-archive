# kernel-boot — AArch64 boot and EL0 cache access

## Scope and ownership

`kernel-boot` supplies architecture boot entry and hands control to runtime
implementations of `PrimaryKernelEntry` and `SecondaryKernelEntry`.
This document covers the AArch64 boot-MMU and EL0 cache-access contract changed
here; it is not a full audit of the other architecture boot paths.

`src/arch/aarch64/entry.rs` owns primary and secondary entry sequencing,
`el.rs` selects the exception-level setup, and `mmu.rs` creates the initial
mappings and programs the current CPU's translation/control registers.
The shared runtime and memory-management layers take over after boot.

## Entry sequence and execution context

The primary path preserves firmware arguments, installs a boot stack,
initializes the exception level and FP/SIMD state, creates boot page tables,
then calls `init_mmu` before switching to the high-address runtime entry.
The secondary path validates its prepared CPU/stack release context, performs
the same exception-level and FP/SIMD setup, then calls the same `init_mmu` using
the already initialized boot tables.

`init_mmu` runs in early privileged boot on each CPU, before any user task.
It does not require a current process, allocator, scheduler or sleepable lock.
Its caller must provide initialized boot page tables and mappings that preserve
the current instruction path, stack and required data across MMU enablement.
The primary creates the shared tables before releasing secondaries; per-CPU
register programming does not mutate those tables.

## MMU and user cache-access policy

`init_mmu` programs MAIR/TCR/TTBR, invalidates the TLB, and updates SCTLR to
enable translation and instruction/data caching. That same update explicitly
sets `SCTLR_EL1.UCT` and `SCTLR_EL1.UCI` to `DontTrap`:

- UCT permits the current CPU's EL0 cache-type register read (`CTR_EL0`).
- UCI removes this SCTLR trap for the EL0 cache-maintenance instructions used
  by user runtimes, including `DC CVAU` and `IC IVAU`.

The subsequent existing SCTLR update and ISB remain in their original order.
Other SCTLR bits are preserved by the register read-modify-write operations.
This initialization belongs in the common per-CPU path: setting only the primary
CPU would leave user behavior dependent on where a task runs.

The observed Chromium failure was `MRS X9, CTR_EL0` trapping as an AArch64 system
register access and subsequently becoming SIGILL. Independent user probes also
trapped on `DC CVAU` and `IC IVAU` before this change. Enabling these two controls
addresses the permission boundary; it does not suppress SIGILL, advance fault PCs,
fake CTR values or change user instruction-cache synchronization algorithms.

The policy follows the ordinary EL1/EL0 configuration with homogeneous CPU cache
characteristics used by the QEMU Cortex-A76 target. Linux's
[initial SCTLR configuration](https://github.com/torvalds/linux/blob/v6.12/arch/arm64/include/asm/sysreg.h#L824)
also includes UCT/UCI, and LLVM's
[AArch64 clear-cache implementation](https://github.com/llvm/llvm-project/blob/llvmorg-20.1.0/compiler-rt/lib/builtins/clear_cache.c#L115)
uses the corresponding register/cache instructions.

## Limits and validation

Instruction permission is only one prerequisite for generated-code execution.
This change does not establish correctness of JIT publication, memory permissions,
barrier placement, cache consistency across CPUs or all browser workloads.
Heterogeneous systems that require a sanitized cache description need a separate
CTR trapping/emulation policy; this boot code does not supply one. VHE and
higher-level virtualization controls have their own semantics and are not
validated by the non-VMM QEMU test.

Validation should compare the same three EL0 instructions before and after the
change, retain a genuinely undefined-instruction SIGILL control, and rerun the
affected Chromium path. A successful probe is not a full stability result.

No new long-lived resource, cleanup path or runtime lock is introduced.
