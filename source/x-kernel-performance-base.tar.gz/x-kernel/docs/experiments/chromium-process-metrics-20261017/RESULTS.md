# Chromium 进程级 CPU 与内存采集：5 轮结果

采集时间：2026-10-17 21:10–21:47（Asia/Shanghai）
运行内核：`93627b2762605be4f35980c457d8dabf724bcc6d11545bb5ed6880f997d9284b`
镜像：`d8904a0f587c65b61ab09602189a82d089a0f77bdedbd3755e8ea9dc79cca486`（pilot 副本）

> **数据身份声明。** 本轮内核来自主工作区未提交的 41 个文件（进程 CPU/内存记账），**不是**交付版本 `ict-final`（`68eed313`）。因此**本文件的数据不进入初赛报告**，只作为决赛素材与"该口径可测量"的方法验证。初赛报告里的资源数字必须来自 `ict-final` 重建后的二进制。

## 1. 目的

在 x-kernel 上取得**浏览器进程自身**的 CPU 时间与内存占用，替代此前只能使用的"客体整机内存 + 宿主 QEMU CPU"代理口径。

## 2. 环境

| 项 | 值 |
| --- | --- |
| 平台 | AArch64 QEMU 8.2.2，`-machine virt,gic-version=3`，`-accel tcg` |
| CPU / 内存 | cortex-a76 × 4 vCPU / 2 GiB，纯 TCG，无硬件加速 |
| 图形 | virtio-gpu-pci，Weston 14.0.2，DRM + Pixman 软件渲染 |
| 浏览器 | Chromium 142.0.7444.59-r0，`--ozone-platform=wayland` |
| 页面 | 官方 `file:///usr/share/kiosk/testpages/index.html`（SHA256 `831cf28f…d176b38`） |
| 采样窗口 | 每轮 300 秒，从 `Popen` 起算，含启动与加载 |
| profile | 每轮新目录，不丢文件系统缓存 |

## 3. 口径（必须随数字一起引用）

- **`chromium_observed_cpu_seconds` 是观察下界。** 它按 `(PID, starttime)` 身份累计每个相关进程**最后一次观察到**的 `utime+stime`，并保留已退出进程；不含父进程已 `wait` 的子进程，避免重复计入。代价是：两次扫描之间创建又退出的短命进程、以及进程退出后到消失之间的尾部时间**可能漏计**。真实 CPU 只会 ≥ 该值。
- **`chromium_sampled_rss_sum_peak_kib` 是 RSS 求和峰值。** 每次扫描把各进程 RSS 相加再取最大值，**共享页被重复计入**，因此**不是 PSS、不是唯一物理内存、不是 cgroup memory.current**。它与"整机已用内存"不可互换。
- CPU 百分比有两种归一化：`…percent_one_vcpu` 以 1 个 vCPU 为 100%；`…percent_all_vcpus` 以 4 个 vCPU 合计为 100%。报告引用时必须写明是哪一种。
- 300 秒窗口**包含浏览器启动**，不是稳态值；稳态需看第 6 节的相位分解。
- 内核 `utime/stime` 为进程所有线程（含已退出线程）的调度驻留时间，休眠不计入；单位取 `SC_CLK_TCK=100`。

采集前做过内核 ABI 对照（客体 Python 探针，非本文件的评分数据）：

| 检查 | 观测 | 结论 |
| --- | --- | --- |
| 忙循环 3 秒 | CPU 4.04s / 墙钟 4.03s | 计数与墙钟 1:1 |
| 休眠 4 秒 | 增量 0.00s | 休眠不计数 |
| 2 秒线程退出后 | 进程总量 4.07s（含启动 1.7s） | 已退出线程时间未丢 |
| 触碰 64 MiB | RSS 65,312 KiB，VSZ 74.3 MiB | rss/vsize 字段可信 |
| `starttime` | 两次读取一致 | 可做 PID 复用判据 |

## 4. 五轮明细

五个相关进程身份共 12 个（browser、zygote、GPU、renderer、utility、crashpad 等）。

| 轮次 | 目录 | CPU 秒 | 单核归一化 | 4vCPU 归一化 | RSS 求和峰值 (KiB) | CDP 就绪 (s) | 退出 (s) | 扫描数 |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | `211044-index-98da4b` | 407.6 | 134.5% | 33.6% | 502,280 | 124.6 | 4.03 | 120 |
| 2 | `211836-index-dd7182` | 389.8 | 128.7% | 32.2% | 506,268 | 127.7 | 4.63 | 118 |
| 3 | `212640-index-2fefa0` | 405.9 | 133.0% | 33.2% | 494,676 | 115.1 | 4.67 | 97 |
| 4 | `213425-index-bd4f6c` | 434.2 | 142.4% | 35.6% | 501,832 | 134.5 | 4.82 | 109 |
| 5 | `214240-index-43f6ed` | 432.9 | 142.2% | 35.6% | 503,332 | 151.7 | 4.36 | 116 |

每轮 `cleanup_complete=true`，退出后 `remaining={}`（无 Chromium/Crashpad 残留）。

## 5. 统计（n=5，中位数 / 极差 / 总体标准差）

| 指标 | 中位数 | 最小 | 最大 | 极差 | σ |
| --- | ---: | ---: | ---: | ---: | ---: |
| CPU 秒（观察下界） | 407.65 | 389.82 | 434.16 | 44.34 | 17.06 |
| 单核归一化 | 134.52% | 128.71% | 142.42% | 13.71 | 5.37 |
| 4vCPU 归一化 | 33.63% | 32.18% | 35.61% | 3.43 | 1.34 |
| RSS 求和峰值 | 502,280 KiB（490.5 MiB） | 494,676 KiB | 506,268 KiB | 11,592 KiB | 3,827 KiB |
| CDP 就绪 | 127.67 s | 115.14 | 151.68 | 36.54 | 12.19 |
| 退出耗时 | 4.63 s | 4.03 | 4.82 | 0.79 | 0.28 |

## 6. CPU 相位分解（5 轮同一桶的中位数，单位：% 单核）

| 窗口 | 中位 | 区间 |
| --- | ---: | --- |
| 0–60 s | 176% | 175–198% |
| 60–120 s | **305%**（峰值） | 298–315% |
| 120–180 s | 120% | 86–206% |
| 180–240 s | 28% | 22–69% |
| 240–300 s | 21% | 18–23% |

结论：**"300 秒平均 33.6%（4vCPU）"几乎全部由前 120 秒的启动与建窗贡献**；页面显示完成后浏览器稳定在约 0.2 个核。报告若只写窗口平均值会严重高估运行时负载，应同时给出启动峰值与稳态两段。

## 7. 与 10-16 数据不可混用

10-16 那批 15 轮（`rootfs-repair-20261016/metrics-data`）用的是内核 `70bc9263`、旧观察器（只采整机 `meminfo`），CDP 就绪中位数 **57.1 s**。本轮用新内核 + 进程级采样器，CDP 就绪 **115–152 s**。

两者差异同时包含三件事：内核不同、采样器不同（本轮每 ~2.5 s 扫描全部 `/proc/PID/stat`，在 TCG 上本身有开销）、镜像不同。**在没做控制变量（只换内核）之前，不能把 57 s 与 128 s 相减声称性能变化**；该对照由 T8 单独执行。

## 8. 复现

```bash
cd /home/cuizh/x-kernel/docs/experiments/manual-pages
DATA=/home/cuizh/x-kernel/target/experiments/chromium-process-metrics-20261017/pilot-data

# 单轮 300 秒
python3 manual_test.py --data-dir "$DATA" measure index --seconds 300

# 5 轮
python3 manual_test.py --data-dir "$DATA" series --pages index --repeats 5 --seconds 300
```

原始数据：`pilot-data/20261017-202207-f845f1/*-index-*/{record.json,guest/process-samples.jsonl,guest/samples.jsonl}`；
汇总：`pilot-data/20261017-202207-f845f1/series-3286a2db.json`。

## 9. 限制

- `page_loaded=false`：官方镜像的 `DeveloperToolsAvailability=2` 策略禁止页面端 CDP 附着，`page_load_event`、FCP 仍缺测。**这不影响 CPU/RSS 有效性，但本轮不能宣称"完整成功"**（`measurement_eligible=false`）。
- 共享页重复计入，RSS 求和高于真实物理占用；需要 PSS 时须另做 `/proc/PID/smaps_rollup` 或页码级统计，当前内核未提供。
- 相位分桶是事后按采样时间切的，不是独立实验组；仅用于解释窗口平均值。
- 单条 300 秒窗口在 TCG 下有 97–120 次扫描，扫描间隔 2.5–3.1 s，短命进程漏计风险真实存在。
