# Chromium zygote 凭据链排查与 Unix 消息修复记录

> **最终进展：** 后续修复 `/proc/<pid>/task` 后，保留 zygote，并使用 `--disable-software-rasterizer --ipc-connection-timeout=120` 的普通内核实验，已实际显示本地 HTML/CSS、JavaScript 计数和 Canvas 动画。查看 [总报告](00_修复报告.md) 与 [第二阶段的最新验收](02_proc-task与浏览器首窗.md)。下文保留第一阶段失败证据，不代表最终仍停在 1002 或 Loading。

> **阶段报告，2026-10-03。** 本文冻结本轮 SCM_CREDENTIALS 修复、243 项 knet 单测、4 个客体回归和首次 Chromium 完整复测的证据。这个阶段已补齐一组真实的内核接口缺口，但**正常 zygote 路径仍出现 `GPU process launch failed: error_code=1002`，尚未验收浏览器窗口**。后续 `/proc/self/task` 修复及补充测试应另列阶段结果，不能用新结果改写这里的修复前证据。

## 1. 结论与实验范围

这次不是继续处理“QEMU 没有显示设备”。Weston 已能启动桌面，之前的 `weston-simple-shm` 也已出现测试窗口。本轮处理的是 Chromium 在创建子进程时依赖的 Linux 兼容行为。

| 结论级别 | 本阶段结论 | 证据 |
| --- | --- | --- |
| 已确认并修复 | Unix DGRAM 的 `SO_PASSCRED` 原先不保存开关、不返回自动凭据；当前能返回实际发送者 PID、真实 UID/GID | [修复前客体日志](evidence/guest/before/unix-passcred.log)、[修复后 DGRAM 日志](evidence/guest/after/unix-passcred-dgram.log) |
| 已确认并修复 | 当前映射到 DGRAM 实现的 SEQPACKET socketpair 同样缺少上述语义 | [修复前 SEQPACKET 日志](evidence/guest/before/unix-passcred-seqpacket.log)、[修复后日志](evidence/guest/after/unix-passcred-seqpacket.log) |
| 已确认并修复 | DGRAM 接收没有正确保留 `MSG_PEEK` 数据包，也没有正确处理逐次接收的 `MSG_DONTWAIT` | [内核单测日志](evidence/run/unit-run.log)、[凭据回归源码](evidence/run/passcred.c) |
| 已确认 | 自动凭据与 `SCM_RIGHTS` 可以共同接收；重复 PEEK 后仍能正常消费，接收的 FD 可使用且支持 CLOEXEC | [握手回归源码](evidence/run/zygote-handshake.c)、[客体结果](evidence/guest/after/zygote-handshake.log) |
| 已确认 | 小控制区内先返回凭据，再处理 FD；凭据部分截断和 `MSG_CTRUNC` 行为通过 Linux 对照 | [22 项截断对照](evidence/guest/after/credentials-truncation.log)、[Linux 结果](evidence/run/credentials-truncation.host.log) |
| 已确认、未解决 | 凭据修复后原始 Chromium 路径仍失败；临时诊断显示 zygote PID 28/29 更早以 133 退出 | [正常复测](evidence/run/fixed/weston-fresh-boot.log)、[临时诊断复测](evidence/run/diagnostic/weston-fresh-boot.log) |
| 已确认的下一项缺口 | 本阶段旧内核的 `/proc/self/task` 链接数恒为 2，与 Chromium 单线程检查和 Linux 行为不符 | [17 项修复前失败](evidence/guest/proc-task-before/proc-task-nlink.log)、[Linux 17 项通过](evidence/run/proc-task/native.log) |
| 尚需后续验收 | zygote 退出是否被下一项修复消除，GPU/renderer 是否继续启动，浏览器是否出现并绘制网页 | 本阶段不宣称完成 |

这里的 `fixed/` 表示“应用了本轮凭据修复的实验组”，**不表示 Chromium 已经修好**。`no-zygote/` 是用于区分启动分支的对照实验，不能当作最终运行方案。

## 2. 环境、版本与归档方式

- 内核仓库：`/home/cuizh/x-kernel`，实验基点 HEAD 为 `8178d538e9c18407ca500c5c3b225d4a59da06f8`，工作区为 dirty。此 HEAD 加现有工作区修改构成实验状态；不能把本实验称为未经修改的官方 tag。
- 目标：`kplat-aarch64` / `aarch64-unknown-none-softfloat`，QEMU TCG，2 GiB RAM、4 vCPU；图形设备为 virtio-gpu，Weston 使用 DRM 后端及 Pixman 软件渲染。
- 实验使用 `/home/cuizh/x-kernel/disk.img`；图形脚本带 `-snapshot`，客体写入进入临时覆盖层。回归 harness 使用根文件系统模板生成独立测试镜像。
- 通过只读检查镜像的 APK installed 数据，确认 Chromium 为 **142.0.7444.59-r0，aarch64**。源码分析固定到上游 `142.0.7444.59` tag；未逐项审计 Alpine 的全部打包补丁，因此发行版差异仍是边界。
- 已有 DRM sysfs、ELF loader、epoll、中断锁、`no_new_privs` 等工作不是本轮凭据补丁的新增成果；保留它们是为了维持当前可启动的实验环境。

归档记录见 [evidence/manifest.json](evidence/manifest.json)，包括原始位置、SHA-256、字节数和采集时间。采集时间为 `2026-10-03T08:36:46Z`。本阶段后续仍在变化的 proc-task 构建和浏览器结果没有纳入这份冻结快照。

归档保留日志、C 回归源码、suite 条目、运行脚本、QEMU 参数、对应上游源文件以及本轮相关 Rust 文件快照。不复制大 ELF、内核二进制、测试可执行文件或磁盘镜像；主要内核二进制保留指纹。24 张 QEMU PPM 截图转换为无损 PNG，清单同时记录原 PPM 哈希。

| 目录/文件 | 用途 |
| --- | --- |
| [evidence/run](evidence/run/) | 原 `/tmp/xkernel-gpu` 中已完成实验的日志、源码与脚本 |
| [evidence/guest/before](evidence/guest/before/) | 修复前的客体逐项输出，包含失败原因 |
| [evidence/guest/after](evidence/guest/after/) | 4 个修复后客体用例原始输出 |
| [evidence/source](evidence/source/) | 本轮涉及文件的完整快照，便于日后按本文行号查阅 |
| [上游源码及原始清单](evidence/run/chromium-source-142.0.7444.59/) | 固定版本 Chromium 源文件及下载来源/哈希 |
| [早期源码分析](evidence/run/chromium-source-analysis.md) | 保留调查过程；其中“当前代码”和“暂未 GPU fatal”等表述是早期观察，应以本文后续完整复测为准 |
| [proc-task 修复前证据](evidence/run/proc-task/) | 下一阶段的失败用例、Linux 对照和对应 Chromium 源码 |

`diagnostic/source/` 是添加 `IPC_DIAG` 之前保存的还原备份，并不包含插桩，不能将它误称为诊断内核的精确源码。诊断运行只用于收集 PID/FD/返回值和退出顺序；这些日志与普通内核验收分别记录。

## 3. 整个故障链：哪些箭头已有证据

```mermaid
flowchart TD
    A[QEMU virtio-gpu 与 Weston 桌面可显示] --> B[启动 Chromium 142 Wayland]
    B --> C[zygote 创建及初始化]
    C --> D[请求 zygote 创建 GPU 等子进程]
    D --> E[SEQPACKET PID 握手需要自动 SCM_CREDENTIALS]
    E --> F[已确认内核缺口：SO_PASSCRED 空操作、没有凭据]
    F --> G[本轮补齐自动凭据、PEEK、DONTWAIT]
    G --> H[243 项 knet 单测与 4 个客体回归通过]
    H --> I[恢复正常 zygote 路径复测]
    I --> J[仍出现 1002 与 GPU unusable]
    C --> K[临时追踪：zygote 28/29 先退出 133]
    L[旧内核 proc task nlink 恒为 2] -. 单线程检查失败的候选原因 .-> K
    K -. 后续请求可能已失去有效 zygote .-> J
    L --> M[下一阶段修复并重新验收]
    B --> N[诊断对照：添加 no-zygote]
    N --> O[直接启动分支进入 GPU 初始化]
    O --> P[ANGLE 所需 Vulkan 扩展缺失]
    P --> Q[EGL 初始化失败并退出 GPU 初始化]
```

实线表示源码契约、直接日志或最小测试已经支持的关系；虚线表示还需要修复后实测闭环的因果判断。凭据缺口是真实问题，但**不能把它画成已证明导致本次所有 1002 的唯一原因**。因为补齐后原始现象仍存在，而且 zygote 本身更早退出。

### 3.1 `1002` 到底是什么

Chromium 的 `LaunchResultCode` 从 `1001` 开始：`LAUNCH_RESULT_SUCCESS` 为 `1002`，通用失败才是 `1003`。Linux zygote 分支调用 `ForkRequest` 后无条件记录 success，随后上层却按进程句柄是否有效选择失败回调，因此会打印看似矛盾的“launch failed: 1002”。这不是 GPU 驱动的 errno。

关键代码，见 [官方枚举](https://github.com/chromium/chromium/blob/142.0.7444.59/content/browser/child_process_launcher.h#L70-L78) 和 [Linux launcher](https://github.com/chromium/chromium/blob/142.0.7444.59/content/browser/child_process_launcher_helper_linux.cc#L85-L113)：

```cpp
enum LaunchResultCode {
  LAUNCH_RESULT_START = 1001,
  LAUNCH_RESULT_SUCCESS,
  LAUNCH_RESULT_FAILURE,
};

// zygote 分支的关键语句
base::ProcessHandle handle = zygote_handle->ForkRequest(
    command_line()->argv(), files_to_register->GetMapping(), GetProcessType());
*launch_result = LAUNCH_RESULT_SUCCESS;
```

[上层 launcher](https://github.com/chromium/chromium/blob/142.0.7444.59/content/browser/child_process_launcher.cc#L194-L219) 按 `process_.process.IsValid()` 分支，无效时调用 `OnProcessLaunchFailed(error_code)`。[GPU host](https://github.com/chromium/chromium/blob/142.0.7444.59/content/browser/gpu/gpu_process_host.cc#L992-L1001) 将它打印出来。相反，直接 `LaunchProcess` 分支会按有效句柄设置 1002 或 1003。

因此下一步应该检查 zygote 为什么没有交回有效子进程，而不是把数字 1002 当成“缺某个显卡驱动”的直接证据。

### 3.2 为什么自动凭据是必须补齐的契约

Chromium 的 PID oracle 创建 `AF_UNIX/SOCK_SEQPACKET` socketpair，在接收端启用 `SO_PASSCRED`。zygote fork 出来的子进程发送 ping，内核应附上**实际发送进程**的 PID。浏览器解析 `SCM_CREDENTIALS` 后，再把 real PID 回给 zygote。

```mermaid
sequenceDiagram
    participant B as 浏览器
    participant K as x-kernel Unix socket
    participant Z as zygote
    participant C as 新子进程
    B->>K: socketpair SEQPACKET
    B->>K: setsockopt 接收端 SO_PASSCRED=1
    B->>Z: fork 请求和 SCM_RIGHTS 中的握手 FD
    Z->>C: fork
    C->>K: 通过继承 FD 发送 ping
    K->>K: 记录发送时 PID、ruid、rgid
    K-->>B: ping + SCM_CREDENTIALS
    B->>Z: ForkRealPID(real_pid)
    Z-->>B: 成功时回复 child_pid
    Note over B,Z: 凭据缺失、zygote 提前退出、消息/回复失败均可破坏该链
```

对应官方代码：[socketpair 与 PASSCRED](https://github.com/chromium/chromium/blob/142.0.7444.59/content/common/zygote/zygote_communication_linux.cc#L102-L107)、[接收 ping 后回传 PID](https://github.com/chromium/chromium/blob/142.0.7444.59/content/common/zygote/zygote_communication_linux.cc#L149-L169)、[凭据解析](https://github.com/chromium/chromium/blob/142.0.7444.59/base/posix/unix_domain_socket.cc#L151-L173)、[负 PID 导致 KillAndReap](https://github.com/chromium/chromium/blob/142.0.7444.59/content/zygote/zygote_linux.cc#L513-L517)。

不能用 socket 创建者的 PID 替代发送者：FD 可以跨 fork 继承、经 `SCM_RIGHTS` 交给其他进程；真正写入消息的进程可能已经不同。`SO_PEERCRED` 和 `SCM_CREDENTIALS` 也不是同一个接口。

## 4. 修复前每个故障点

### 4.1 PASSCRED“成功返回”，但实际没有效果

原 DGRAM 的 `PassCredentials` get/set 分支为空操作，用户态 `setsockopt` 虽然返回成功，但随后 getsockopt 仍读到 0，recvmsg 也没有凭据。STREAM 同样存在空操作，不过不在这次修复范围内。

修复前 [SEQPACKET 日志](evidence/guest/before/unix-passcred-seqpacket.log) 中有 `expected=1 actual=0`，随后第一次 PEEK 收到普通字节却没有 `SCM_CREDENTIALS`。这比浏览器的最终报错更接近接口本身。

### 4.2 PEEK 消耗了本该留在队列中的消息

普通接收把消息从队列取走是正确行为；`MSG_PEEK` 则要求这次查看后仍能再次读到同一个消息，包括携带的文件引用。原 DGRAM 路径没有这个保留状态，第二次 PEEK 无法继续读取同一条消息。

回归刻意使用 fork 子进程发送一次、父进程 PEEK 两次、最后普通接收一次，以同时验证消息、身份和生命周期。如果只测一次 recvmsg，会漏掉这个问题。

### 4.3 `MSG_DONTWAIT` 没有阻止空队列阻塞

探针每次 `recvmsg` 都附加 `MSG_DONTWAIT`，并设置 alarm 作为最后兜底。原实现丢失 PEEK 消息后，下一次接收没有立即返回 EAGAIN，而是阻塞至 alarm；修复前日志的退出 142 是探针的限时失败，不能解释为内核主动正确处理了非阻塞请求。

### 4.4 控制消息不是“只要把 UID/PID 拼进去”

除了编码 `ucred`，还必须解决：凭据来源可信；真实 UID/GID 不写死为 root；控制区不足时设置 CTRUNC；自动凭据与 FD 同时出现时顺序正确；PEEK 不转移队列中的唯一文件引用；释放最后一个引用时不重入仍持有的接收锁。

这些条件分别由下述设计和回归覆盖，而不是依靠“Chromium 没打印错误”推定成功。

## 5. 修复设计、代码位置与生命周期

下列行号对应 [evidence/source](evidence/source/) 中的冻结快照；工作区继续修改后以快照为准。

| 位置 | 修改职责 |
| --- | --- |
| `net/knet/src/socket/mod.rs:189–196` | 定义仅由可信内核路径产生的 `KernelAncillaryData::UnixCredentials` 标签 |
| `net/knet/src/unix.rs:321–340` | 在公共 socket send 边界捕获实际发送进程及真实 UID/GID，凭据插入控制对象列表首部 |
| `net/knet/src/unix/dgram.rs:30–35,57–64` | 接收状态增加 `peeked`；维护 PASSCRED 标志 |
| 同文件 `127–165` | 实现 PASSCRED 的读取和修改 |
| 同文件 `255–314` | 处理 PEEK、DONTWAIT、TRUNC、凭据过滤和锁外释放 |
| 同文件 `318–340` | 队首保留消息也必须报告可读，注册对应接收 poll 对象 |
| `posix/net/src/cmsg.rs:139–167` | 按本机 Linux ABI 编码 12 字节 ucred 并报告部分截断 |
| `posix/net/src/io.rs:105–164` | 区分 RIGHTS 与可信内核凭据，并编码回用户态控制区 |
| `net/knet/src/socket/general.rs` | 移除不再使用的普通接收轮询包装，使用已有支持逐次 nonblocking 的入口 |

### 5.1 发送端：身份在发送时捕获，凭据先于 FD

完整快照：[unix.rs](evidence/source/net/knet/src/unix.rs)。关键实现：

```rust
if matches!(self.transport, UnixTransport::Dgram(_))
    && let Some(thread) = ktask::current().try_as_thread()
{
    let cred = kprocess::current_cred();
    options.ancillary.insert(
        0,
        Arc::new(crate::KernelAncillaryData::UnixCredentials(
            crate::options::UnixCredentials {
                pid: thread.pid(),
                uid: cred.ruid(),
                gid: cred.rgid(),
            },
        )),
    );
}
```

`thread.pid()` 取所属进程的 PID，不是 TID。把入口放在 socket send 边界也覆盖经 VFS `write` 的发送。纯内核调用者没有用户进程身份时，不伪造一份 root 凭据。

使用 `insert(0, ...)` 是有意的：在 64 位 ABI 下，32 字节控制区刚好容纳完整 ucred 的对齐空间。如果同一消息还携带 FD，Linux 对照先返回完整凭据，再因装不下 FD 报 `MSG_CTRUNC`。先输出 RIGHTS 会改变接收方能观察到的内容。[截断对照源码](evidence/run/credentials-truncation.c)专门验证了这个情况。

### 5.2 接收端：队列、PEEK 和 poll 共用同一状态

```rust
struct ReceiveState {
    receiver: async_channel::Receiver<Datagram>,
    poll: Arc<PollSet>,
    peeked: Option<Datagram>,
}
```

异步队列没有直接窥视接口，因此首次接收先把队首消息放进 `peeked`；PEEK 只复制消息及控制对象引用，普通接收才把它取走。整个状态受接收 mutex 保护，避免并发读者改变队首顺序。`poll()` 同时检查 `peeked.is_some()` 和底层队列，防止消息已取入缓存却错误地报告不可读。

```mermaid
flowchart LR
    S[发送时不可变身份和文件引用] --> Q[底层消息队列]
    Q --> R[ReceiveState.peeked 队首缓存]
    R --> P[PEEK：复制数据与 Arc 引用]
    P --> R
    R --> C[普通接收：take 队首消息]
    C --> F[按 SO_PASSCRED 过滤凭据标签]
    F --> E[POSIX 编码凭据并安装接收端 FD]
    E --> U[复制控制区到用户态]
    C --> D[接收锁释放后再释放已消费消息]
    R --> I[poll 保持 IN 可读]
```

PASSCRED 标志使用独立的 `AtomicBool`；它只决定本次是否导出已经捕获好的身份，不负责发布消息内容，因此这里使用 Relaxed。队列及队首缓存的一致性仍由接收状态锁维护。

### 5.3 为什么必须在接收锁外释放消息

消息可能携带 socket 文件引用，释放最后一个引用会进入文件或 socket 的析构。析构路径可能重新访问接收状态，若此时仍持有接收锁，就可能造成重入死锁。

关键代码 [dgram.rs:255–282](evidence/source/net/knet/src/unix/dgram.rs)：

```rust
// consumed 先声明，guard 后声明：退出作用域时先释放 guard。
let consumed;
let mut guard = self.rx.lock();
let Some(state) = guard.as_mut() else {
    return Err(KError::NotConnected);
};
// 省略将底层队首填入 state.peeked 的代码。
consumed = if is_peek { None } else { state.peeked.take() };
let packet = consumed.as_ref().or(state.peeked.as_ref()).unwrap();
let count = dst.write(&packet.data)?;
```

Rust 局部变量按声明的逆序销毁。这里的声明顺序保证普通返回和 `dst.write(...)?` 错误返回都先释放 guard，再释放 consumed。测试用一个析构时尝试重新获取接收锁的探针，覆盖成功复制和 EFAULT 两条路径。

PEEK 遇到复制失败仍保留原消息；普通消费发生复制失败时，沿用本模块此前的“消息已离队”行为。这是明确的错误路径语义，不把两者混为一谈。

### 5.4 用户态控制区：类型边界、截断与 FD 回滚

完整快照：[cmsg.rs](evidence/source/posix/net/src/cmsg.rs)、[io.rs](evidence/source/posix/net/src/io.rs)。编码核心：

```rust
fn unix_credentials_bytes(cred: &knet::options::UnixCredentials) -> [u8; 12] {
    let mut bytes = [0; 12];
    bytes[..4].copy_from_slice(&cred.pid.to_ne_bytes());
    bytes[4..8].copy_from_slice(&cred.uid.to_ne_bytes());
    bytes[8..].copy_from_slice(&cred.gid.to_ne_bytes());
    bytes
}
```

三个字段各占 4 字节，按本机字节序编码，避免直接拷贝 Rust 结构体时把填充字节当作 ABI。控制消息头使用 `SOL_SOCKET/SCM_CREDENTIALS`；若正文只能复制一部分，编码函数返回“不完整”，由上层设置 `MSG_CTRUNC`。

自动身份使用 `KernelAncillaryData` 标签，与从用户输入解析出的 `CMsg::Rights` 分开。本轮没有开放用户传入任意 `SCM_CREDENTIALS`，因此用户不能通过构造控制字节伪造这一内核标签。

PEEK 中的文件引用采用 clone，使每次接收都能分配接收进程自己的 FD，队列仍持有原文件对象。FD 安装、用户态控制区复制失败后的撤销，继续使用已有事务路径；这次增加的凭据分支不另起一套 FD 生命周期。重复 PEEK 得到的 FD 必须由应用分别关闭，即使数字可能被关闭后的描述符槽位复用。

## 6. 验证结果：内核接口与浏览器分开验收

### 6.1 构建和静态检查

[make clippy](evidence/run/clippy.log)、[make build](evidence/run/build-final.log) 成功。日志仍有已存在的 future-incompatibility 提示；本报告不把它们计作新的修复成果，也不把“构建通过”替代运行验证。

### 6.2 内核单元测试：243 项仅覆盖 knet

[原始运行日志](evidence/run/unit-run.log)结尾为：

```text
Test results: 243 passed, 0 failed, 0 ignored, 243 total
UNITTEST_STATUS: ALL_TESTS_PASSED
```

新增并通过的 DGRAM 测试包括 PASSCRED 开关、过滤凭据时保留其他控制对象、重复 PEEK 后顺序及可读性、丢弃控制对象时在锁外析构、失败 PEEK 保留消息、空队列非阻塞接收，以及 TRUNC 返回完整消息长度。

本次运行传入了 `UNITTEST_CRATE=knet,posix-net`，但测试模块路径采用 Rust crate 名 `posix_net`。过滤器只按模块名前缀匹配，不自动把连字符改成下划线，因此实际 243 项都是 knet。**不能声称这次已跑过 posix_net 的新凭据编码测试**；它在该阶段仍需使用 `posix_net` 正确补跑，结果由后续记录补充。

### 6.3 独立 Linux 对照和 aarch64 客体回归

| 用例 | 重点 | 本阶段客体结果 |
| --- | --- | --- |
| `unix-passcred-dgram` | 开关读写、fork 后实际发送者、两次 PEEK 再消费、无控制区 CTRUNC、关闭 PASSCRED | 32 checks，0 failures |
| `unix-passcred-seqpacket` | 对 DGRAM 实现承载的 SEQPACKET socketpair 重复以上契约 | 32 checks，0 failures |
| `zygote-handshake` | 子进程降低 UID/GID；凭据和 RIGHTS 混合；PEEK 两次；CLOEXEC；消费后通过传递的 FD 实际写入管道 | PASS |
| `credentials-truncation` | 两种 socket × 小控制区/部分正文；32 字节时凭据先于 FD | 22 cases，0 failures |

[harness 汇总](evidence/run/fixed-harness.log)：4/4 PASS，约 27 秒。每个用例使用独立镜像，退出状态均为 0。[suite 条目](evidence/run/suite-entry.toml)保留了注入路径与超时。

截断对照的控制区大小为 0、15、16、17、20、24、27、28、31、32 字节；另有每种 socket 各一项凭据加 FD 的 32 字节混合测试，共 22 项。宿主 Linux 的相同源码也通过，见 [host log](evidence/run/credentials-truncation.host.log)。这些数值对应实验中的 64 位 ABI，不应直接当作所有架构的固定常数。

### 6.4 Chromium 完整复测：仍然失败

正常 zygote 组完整日志记录的首个 GPU launch failure 时间为 `08:17:06.127797`，最终 `08:17:14.994228` 打印 `GPU process isn't usable. Goodbye.`。脚本反复输出 tail，最后又 cat 全日志，所以文件里的同一报错会重复出现；必须按报错自带时间/PID 去重，不能把每一行重复打印都计为一次新故障。

![凭据修复后正常 zygote 组末次截图](evidence/run/fixed/chromium-6.png)

截图仍未提供浏览器窗口成功的证据；桌面背景、浏览器主进程存活、某个 GPU 子进程短暂出现都不足以判定 Chromium 跑通。

进一步临时追踪在 [diagnostic 日志](evidence/run/diagnostic/weston-fresh-boot.log) 354、363 行附近记录：

```text
[25.435389] IPC_DIAG exit pid=28 tid=28 code=133 group=true
[26.181225] IPC_DIAG exit pid=29 tid=29 code=133 group=true
```

对应 Chromium 日志将 PID 28/29 标识为 `ZygoteMain`。它们先退出，之后浏览器才继续报 GPU 启动失败。这说明需要优先查 zygote 初始化阶段。单凭退出码 133 不能定位具体 CHECK 或系统调用；日志里出现的普通数据和 FD 交换，也不能在没有协议核对的情况下全部称为 PID oracle 握手。

## 7. 两个后续方向及其证据强度

### 7.1 优先方向：`/proc/self/task` 的动态链接数

Chromium 142 的 [thread_helpers.cc:37–48](https://github.com/chromium/chromium/blob/142.0.7444.59/sandbox/linux/services/thread_helpers.cc#L37-L48) 使用如下逻辑：

```cpp
int fstat_ret = fstatat(proc_fd, "self/task/", &task_stat, 0);
PCHECK(0 == fstat_ret);
CHECK_LE(3UL, task_stat.st_nlink);
return task_stat.st_nlink == 3;
```

本阶段旧内核给 `/proc/self/task` 返回恒定 `st_nlink=2`。独立 [proc-task-nlink.c](evidence/run/proc-task/proc-task-nlink.c) 验证：单线程应为 3，增加线程后变为 4、5，线程退出后回到 3；同一已经打开的目录 FD 的 fstat 也应反映变化，不能只在首次创建目录时计算一次。还覆盖 `fstatat(proc_fd, "self/task/")`、self/numeric PID 路径及 fork 子进程。

宿主 Linux 17 项全通过，旧 x-kernel 17 项全失败。这个接口缺口已确认；它与 zygote 提前退出的因果闭环，需要后续修复后重跑原始 Chromium 命令，不在本阶段冒充已验证。

### 7.2 分支对照：`--no-zygote` 进入了另一层 GPU 初始化失败

添加 `--no-zygote` 会让 [GetZygoteForLaunch](https://github.com/chromium/chromium/blob/142.0.7444.59/content/browser/child_process_launcher_helper_linux.cc#L184-L188) 返回空，从而走直接进程启动。它适合区分启动链问题，不是最终修复。

[no-zygote 完整日志](evidence/run/no-zygote/weston-fresh-boot.log)中 PID 48 的关键顺序为：

1. `08:04:04.919356`：`drmGetDevices2()` 没找到设备，随后是 render-node 初始化警告。它是较早错误，但日志本身不足以证明这一步一定导致最后退出。
2. `08:04:06.153004` / `08:04:06.160245`：ANGLE 明确报缺少 `VK_EXT_headless_surface`、`VK_KHR_surface`。
3. Vulkan 返回 `-7`，ANGLE/SwANGLE 的 EGL 初始化失败，所有 EGL display 类型初始化失败。
4. `gpu_init.cc:510` 报 `InitializeGLNoExtensionsOneOff failed`。
5. `08:04:06.802280`：`viz_main_impl.cc:189` 明确退出 GPU 初始化。

这个链比后面出现的 crashpad `missing credentials` 或进程退出码更接近该对照组的第一次明确初始化失败。后续日志不能倒过来充当前面失败的唯一原因。

`--disable-gpu` 并不保证不会进入软件 GL；Chromium 的软件 GL 模式仍可能初始化 SwANGLE。下一阶段可以单独加入 `--disable-software-rasterizer` 作分支对照，或直接检查客体实际加载的 Vulkan 实现及其扩展列表；不能仅因看到该日志就安装一批驱动。[GPU 模式选择源码](https://github.com/chromium/chromium/blob/142.0.7444.59/content/browser/gpu/gpu_data_manager_impl_private.cc#L502-L529)、[参数处理](https://github.com/chromium/chromium/blob/142.0.7444.59/content/browser/gpu/gpu_data_manager_impl_private.cc#L608-L616)、[初始化退出源码](https://github.com/chromium/chromium/blob/142.0.7444.59/components/viz/service/main/viz_main_impl.cc#L184-L197)。

已归档的 `software-only/` 是另一组启动参数对照，应结合其脚本和日志阅读；本阶段仍未验收出浏览器窗口，不能写成成功替代方案。

## 8. 如何复现，以及每条命令的作用

以下是可复用步骤说明，不表示阅读本文时已经再次执行。**Ubuntu 宿主命令与 `kylin-x:~#` 客体命令分开执行。** 原实验脚本都在 `evidence/run/*/check.py`，其 `/tmp/xkernel-gpu/...` 路径是实验现场路径；从归档目录重跑时应先调整路径，不要直接覆盖原证据。

### 8.1 宿主：按项目流程配置、检查和构建

```bash
cd /home/cuizh/x-kernel
cp platforms/kplat-aarch64/qemu_defconfig .config
CARGO_NET_OFFLINE=true make defconfig
CARGO_NET_OFFLINE=true make clippy
CARGO_NET_OFFLINE=true make build
```

- `cd` 切到仓库根目录。
- `cp ... .config` 用 aarch64 QEMU 模板准备构建配置，会替换当前 `.config`；如有自定义配置，应先保留副本。
- `make defconfig` 解析配置并产生后续构建使用的配置结果。
- `make clippy` 走项目的 Kconfig 构建入口做 Rust 静态检查；`make build` 生成内核。
- 命令前的 `CARGO_NET_OFFLINE=true` 仅作用于该次命令，要求 Cargo 使用已有依赖缓存。本轮没有以安装新依赖来规避故障。

正确的单测过滤名应使用下划线：

```bash
CARGO_NET_OFFLINE=true make UNITTEST=y UNITTEST_CRATE=knet,posix_net \
  run ACCEL=n VSOCK=n GRAPHIC=n MEM=2g SMP=4
```

`UNITTEST=y` 选择内核单测入口；`UNITTEST_CRATE` 限定测试模块；`ACCEL=n` 使用软件模拟；`VSOCK=n` 不依赖宿主 vhost-vsock；其余参数分别控制图形、内存、vCPU。反斜杠接换行只为把同一条命令排成多行，其后不要多出空格。补跑结果需要另存日志，并确认日志里实际出现 `posix_net::...`。

### 8.2 宿主：构建最小客体测试

以已经安装的 aarch64 musl 交叉编译器构建，不需要把 Ubuntu 的 x86_64 程序直接复制进客体：

```bash
/home/cuizh/toolchains/aarch64-linux-musl-cross/bin/aarch64-linux-musl-gcc \
  -static -O2 -Wall -Wextra -Werror \
  /home/cuizh/x-kernel/docs/experiments/chromium-zygote-credentials/evidence/run/passcred.c \
  -o /tmp/passcred-aarch64
```

编译器前缀决定目标为 aarch64；`-static` 减少客体动态库依赖；`-O2` 优化；`-Wall -Wextra -Werror` 将常见编译警告作为错误；`-o` 指定输出文件。对另外两个 C 文件使用相同选项和不同输出名。宿主 Linux 对照则使用宿主 `cc` 构建，不能把两者混用。

本轮通过外部 Starry Test Harness 注入并运行测试，注册规则见 [suite-entry.toml](evidence/run/suite-entry.toml)。已配置好的现场可以使用下面的运行选择；若从新目录复现，须先按 suite 中的 `inject.src` 放好交叉编译后的文件，并将 suite 条目加入迭代测试套件。

```bash
cd /tmp/xkernel-scm-tests/starry-test-harness
env CARGO_NET_OFFLINE=true STARRY_SKIP_BUILD=1 \
  STARRY_ROOTFS_TEMPLATE='/home/cuizh/Desktop/ICT产教融合/agentos-disk.img' \
  XKERNEL_REMOTE=/tmp/xkernel-gpu/fixed/fixed-root \
  STARRY_ACCEL=0 STARRY_VSOCK=off NET=n INPUT=n GRAPHIC=n MEM=2g SMP=4 \
  CASES=unix-passcred-dgram,unix-passcred-seqpacket,zygote-handshake,credentials-truncation \
  make ci-test-iter run ARCH=aarch64
```

这里跳过的是 harness 自己的内核构建，使用指定目录内的实验内核；根文件系统模板用于生成隔离测试镜像；`CASES` 只选择这 4 项用例。原始客体日志已记录实际内核路径、磁盘路径和 QEMU 命令，比只看终端最终 PASS 更便于复现。

### 8.3 客体：启动 Weston 并运行原始 Chromium 路径

若本次客体尚未启动 seatd/Weston，使用：

```bash
export XDG_RUNTIME_DIR=/run/user/0
mkdir -p "$XDG_RUNTIME_DIR"
chmod 700 "$XDG_RUNTIME_DIR"
SEATD_VTBOUND=0 seatd -g root -l debug > /tmp/seatd-test.log 2>&1 &
LIBSEAT_BACKEND=seatd SEATD_SOCK=/run/seatd.sock \
  weston --backend=drm --renderer=pixman --drm-device=card0 \
  --continue-without-input --idle-time=0 --log=/tmp/weston-test.log \
  > /tmp/weston-test-stderr.log 2>&1 &
```

运行目录保存 Wayland socket；`chmod 700` 让该目录仅当前用户访问。seatd 管理设备访问，`SEATD_VTBOUND=0` 适配当前没有常规虚拟终端切换的实验环境。Weston 选择 DRM 显示和 Pixman 软件渲染。`>` 保存标准输出，`2>&1` 让标准错误写入同一文件，末尾 `&` 放到后台。已有进程在运行时不应重复启动第二份。

先查看 socket 名称，使用实际存在的名字：

```bash
ls -l /run/user/0
export WAYLAND_DISPLAY=wayland-1
chromium --ozone-platform=wayland --no-sandbox --disable-gpu \
  --user-data-dir=/tmp/chromium-credentials-validation \
  --no-first-run --enable-logging=stderr --v=1 about:blank \
  > /tmp/chromium-test.log 2>&1 &
```

`wayland-1` 只是本次已观测到的例子；若新启动实际是 `wayland-0`，必须相应修改。Ozone 参数选择 Wayland；独立 user-data-dir 避免混用测试配置；`--v=1` 增加诊断日志；`about:blank` 先排除外部网站网络因素。`--no-sandbox` 是本次 root 客体受控排障的现有设置，不代表完成了沙箱兼容性。

先保留不带 `--no-zygote` 的这条命令作为回归基准。仅在单独诊断组添加该开关，日志和配置目录也要区分。

```bash
ps
tail -n 100 /tmp/chromium-test.log
tail -n 80 /tmp/weston-test.log
```

`ps` 看进程是否存在，`tail -n` 看日志最后指定行数。这些 `/tmp` 文件位于客体文件系统，不是 Ubuntu 宿主的 `/tmp`；退出 QEMU 后直接在宿主执行同名 tail，并不能读取客体日志。快照模式的客体写入也不会自动永久保存到原 disk.img，所以应在退出前导出实验需要的日志。

## 9. 已知边界与下一阶段验收清单

本轮实现有明确边界：

- 自动 `SCM_CREDENTIALS` 仅覆盖 DGRAM 和目前由 DGRAM 实现承载的 SEQPACKET socketpair；STREAM PASSCRED 仍未实现。
- 用户显式发送 `SCM_CREDENTIALS` 仍拒绝；没有实现 Linux capability 授权的 PID/UID/GID 例外规则。
- `SO_PEERCRED` 仍有原有近似行为，不能据此宣称 Unix 凭据功能全面兼容 Linux。
- 当前使用全局 PID/身份，没有新增 PID namespace 或 user namespace 的身份翻译。
- 发送时总是捕获身份，因此接收端在消息入队后才开启 PASSCRED 的场景，与 Linux 某些 dummy credentials 行为可能不同；PASSCRED 触发的自动绑定也没有补齐。
- 没有扩展完整 SEQPACKET listen、shutdown、EOF/HUP 行为；没有解决无界 DGRAM 队列、Unix FD 引用环回收及 in-flight 配额等既有问题。
- Linux x86_64 宿主对照和 aarch64 客体通过的测试，不等价于所有架构、所有并发压力及安全边界均已验证。

本阶段结束时拟定的后续验收顺序如下；已经完成的后续工作见 [第二阶段报告](02_proc-task与浏览器首窗.md)：

1. 用正确过滤名补跑 posix_net 凭据编码测试，保留模块名与总数。
2. 修复 `/proc/<pid>/task` 动态链接数，保证同一打开的目录 FD 也能反映线程增减；运行 17 项对照。
3. 移除临时 IPC_DIAG 插桩，用普通内核重新跑正常 zygote 路径，确认 zygote 不再提前退出、1002 是否消失。
4. 若推进到 GPU 初始化，再单独处理软件 GL/Vulkan 等后续层，不把不同阶段错误拼成同一个原因。
5. 以可见 Chromium 窗口、可绘制本地测试页及明确日志作为端到端验收；再补输入、页面功能和稳定性测试。

第一阶段证据冻结后，主任务已补充第二阶段报告，生成 [本轮补丁](patches/本轮修改.patch) 和当前源码快照。补丁没有混入此前 ELF、epoll、no_new_privs 等代码修改；尚未提交或推送 Git。最终开发记录入口汇总两个阶段。
