# /proc/task 动态链接数与 Chromium 首个窗口

日期：2026-10-03；AArch64 QEMU，2 GiB，4 核；Chromium 142.0.7444.59-r0。

## 结论

前半轮已修复 Unix 数据报凭据和 PEEK，但原 Chromium 仍然报 1002。本阶段进一步修复 `/proc/<pid>/task` 恒报 `st_nlink=2` 的问题。修复后，保留 zygote 的普通启动已能创建 GPU 子进程；额外加 `--disable-software-rasterizer` 的对照组出现了 Chromium 窗口、标签栏及地址栏。

最终追加验证已成功：在普通内核中再增加 `--ipc-connection-timeout=120` 后，本地 HTML/CSS、JavaScript 计数和 Canvas 动画均显示并持续更新，见文末“最终页面验收”。下文保留默认超时组失败的调查过程。原参数下的 Vulkan/ANGLE 初始化问题尚未修复。

## 故障链：先修身份消息，再修线程目录

```mermaid
flowchart TD
    A[启动 Chromium] --> B[派生 zygote]
    B --> C[输出 initializing 0 fork delegates]
    C --> D[EnterLayerOneSandbox]
    D --> E[IsSingleThreaded: fstatat self/task/]
    E --> F{目录 nlink 是否至少为 3}
    F -- 修复前为 2 --> G[触发 Chromium CHECK]
    G --> H[zygote 退出133；浏览器发送时 BrokenPipe]
    H --> I[ForkRequest 返回无效进程句柄]
    I --> J[错误路径打印数值1002]
    F -- 修复后单线程为 3 --> K[继续处理 zygote 请求]
    K --> L[SCM_RIGHTS 与 SCM_CREDENTIALS 传递]
    L --> M[真正派生 GPU 子进程]
    M --> N{软件 GL 回退}
    N -- 默认允许 --> O[缺 Vulkan 扩展，ANGLE/EGL 初始化失败]
    N -- 关闭回退的对照 --> P[出现 Chromium 窗口]
```

固定版本源码中，`zygote_main_linux.cc:201` 先打印初始化日志，`:208` 调用 `EnterLayerOneSandbox`，后者 `:145` 执行单线程检查。`thread_helpers.cc:40–48` 通过 `fstatat(proc_fd, "self/task/", ...)` 检查链接数至少为 3，再以恰好等于 3 判断单线程。`--no-sandbox` 不会取消这次检查。

直接证据包括：修改前客体 `stat` 返回 2；多线程 C 回归 17 项全部失败且值始终为 2；诊断内核记录两个 zygote 先退出 133，父进程随后 BrokenPipe；修改后 17 项全部通过，并能派生 GPU。没有取得原始 CHECK 的异常 PC，因此“精确落在哪条 BRK 指令”不是已证明事项；源码、ABI 复现及修改前后行为共同支持该故障链。

1002 本身是 Chromium 的 `LAUNCH_RESULT_SUCCESS` 枚举值。zygote 启动帮助函数即使拿到无效句柄仍设置这个枚举，外层依据句柄判失败后输出该数值；它不是 Linux errno，也不能直接解读成“GPU 硬件故障”。详细来源见前半轮报告。

## 修复位置与代码

### 1. KVFS 提供动态链接数查询

位置：[simple_dir.rs](/home/cuizh/x-kernel/fs/kvfs/src/simple_dir.rs:146)，查询应用位置约 `:450`。

```rust
fn link_count(&self) -> VfsResult<Option<u64>> {
    Ok(None)
}
```

默认返回 `None`，保留其他简单目录原有行为。在每次 `getattr` 中，先获取节点元数据并释放其锁，再调用后端：

```rust
let mut metadata = self.dir.node.getattr(idmap, path, request_mask, query_flags)?;
if let Some(count) = self.dir.ops.link_count()? {
    metadata.nlink = count;
}
Ok(metadata)
```

因此已经打开的目录也会返回新值，不能只在第一次构造 inode 时设置常量 3。`ChainedDirOps` 转发第一个非空结果，错误原样传递；返回值表示整个目录的权威计数，不累加各后端。

### 2. procfs 使用目标进程当前成员数

位置：[root.rs](/home/cuizh/x-kernel/fs/filesystems/procfs/src/task_nodes/root.rs:54)。

```rust
fn link_count(&self) -> VfsResult<Option<u64>> {
    let process = self.process.upgrade().ok_or(VfsError::NoSuchProcess)?;
    Ok(Some(2 + procfs::thread_count(&process) as u64))
}
```

这里的 2 对应目录自身及父目录链接，再加每个线程子目录；单线程为 3、两个线程为 4、三个线程为 5。Linux `proc_task_getattr` 同样把目录原链接数与线程数相加。

位置：[procfs.rs](/home/cuizh/x-kernel/process/kprocess/src/procfs.rs:56)。新入口复用现有 `Process::thread_count()`；它在成员锁下扫描已发布且仍可升级的弱引用，O(n)，不分配 TID 向量。没有另建需要同步维护的原子计数器。

```mermaid
sequenceDiagram
    participant U as stat / fstat / fstatat
    participant V as KVFS getattr
    participant D as ProcessTaskDir
    participant P as Process 成员表
    U->>V: 请求目录属性
    V->>V: 读取基础元数据并释放属性锁
    V->>D: link_count()
    D->>P: 统计当前已发布线程
    P-->>D: 本次线程数
    D-->>V: 2 + 线程数
    V-->>U: 本次 Metadata
```

生命周期边界：目标进程弱引用失效返回 ESRCH；进程身份还存在、线程数为零时返回 2。计数只是一次观察，多次系统调用之间允许线程变化；它不构成永久的单线程保证，也未补全 procfs 权限、命名空间或 Chromium 沙箱。

## 验证记录

| 验证 | 结果 |
| --- | --- |
| 宿主 Linux 的 C 行为对照 | 17/17 通过 |
| 修复前客体，同一个 C 程序 | 17/17 失败，计数固定 2 |
| 修复后客体 | 17/17 通过 |
| posix_net、kvfs、procfs、kprocess 单元测试 | 272 passed，0 failed |
| 新增凭据编码单测 | 本次明确匹配 posix_net 并通过 |
| 新增 KVFS 动态属性及默认属性两项单测 | 均通过 |
| make clippy、普通 make build | 离线通过 |
| Chromium 原参数 | 1002 未再出现；GPU 已派生，Vulkan/ANGLE 初始化失败 |
| 额外关闭软件 GL 回退 | 实际出现 Chromium 首窗，保留 zygote |

C 回归验证 `stat`、与 Chromium 相同的 `fstatat`、数字 PID 路径及同一个已打开目录的 `fstat`，观察线程从 1→2→3→1 的变化，并检查 fork 后子进程的 `/proc/self/task`。使用条件变量同步存活线程；退出后有界等待成员回收，不用任意长睡眠冒充通过。

前半轮 243 个测试只覆盖 knet：当时过滤器误用了 Cargo 包名 `posix-net`，运行器实际匹配 Rust 模块名 `posix_net`。本次已补跑并确认新增凭据编码测试在 RESULT 中通过，不把此前漏跑记成成功。

日志、测试源码、suite 注册、实际 QEMU 参数及源码来源保存在 [evidence/proc-task](evidence/proc-task/)。测试使用官方镜像副本或 `-snapshot`，不修改工作 disk.img。普通测试内核 build-id 为 `85c20a8fce425c6940c674ed3739e0dac71a60833547d9505979c83d42692598`；临时诊断后的重新构建具有新时间及 build-id，见 `bundle-restored.toml` 与 `kernel-identities.json`，二者源码修复相同，不能声称二进制哈希相同。

临时 USER_TRAP 诊断由于过早读取尚不存在的 `/proc/55/maps` 而提前结束，不能作为完整运行“无异常”的证据。诊断代码已经移除，普通内核已重新构建。

## 启动参数与命令解释

在 QEMU 里的 `kylin-x:~#`，确认 Weston 已启动、Wayland socket 存在后，可以使用：

```sh
export XDG_RUNTIME_DIR=/run/user/0
export WAYLAND_DISPLAY=wayland-1
chromium --ozone-platform=wayland --no-sandbox \
  --disable-gpu --disable-software-rasterizer \
  --user-data-dir=/tmp/chromium-smoke --no-first-run \
  --enable-logging=stderr about:blank > /tmp/chromium-smoke.log 2>&1 &
```

`WAYLAND_DISPLAY` 要按实际 socket 名填写，本实验脚本自动查找。`--ozone-platform=wayland` 连接 Weston；两个 disable 参数分别关闭 GPU 加速和软件 GL 回退，不代表禁止全部 CPU 页面绘制。`--no-sandbox` 是当前调试条件，不是沙箱验收。临时用户目录隔离浏览器配置，`--no-first-run` 跳过首次运行流程，日志参数把日志写到标准错误；`>` 保存日志、`2>&1` 合并错误输出、`&` 放到后台，行末 `\` 表示命令续行。本轮未安装或下载软件包，也未提交或推送 Git。

![普通修复内核、软件绘制对照组的 Chromium 首窗](evidence/proc-task/chromium-software-only/chromium-6.png)

## 本地网页验收：首窗成功，正文尚未渲染

已在新的 QEMU 快照中创建 `/tmp/xkernel-smoke.html`，包含标题、CSS 彩色网格、每秒更新的 JavaScript 计数和 Canvas 动画。保留 zygote，使用 `--disable-gpu --disable-software-rasterizer` 启动该文件；连续观测并截取 10 帧。

最终两帧均出现 Chromium 窗口和文件地址，但标签仍为 `Loading…`，测试正文、彩色网格和计数未出现。因此本阶段验收为：**浏览器窗口通过；HTML/CSS/JavaScript 页面测试未通过**。不能根据空白页或单纯进程存活宣称 Chromium 已完全运行。

客体 `/proc` 的命令行快照可能仍保留 fork 前的 zygote 参数，不应仅据此判断所有子进程都仍在执行 zygote 主循环。后续需区分 renderer 创建、Mojo 通信、页面加载和提交。额外的 `--no-zygote` 对照及异常日志实验只用于缩小边界，不能替代标准子进程路径验收。

![本地页面观测末帧：浏览器显示文件地址，正文尚未渲染](evidence/proc-task/page-smoke/chromium-10.png)

## 已缩小的剩余故障：子进程连接 watchdog

两组额外对照都执行完成：`--no-zygote` 加相同软件绘制参数，仍然只有窗口、页面 Loading；保留 zygote 的临时异常诊断内核也如此，完整观测中未捕获 USER_TRAP。后者只是有限时间窗口内没有捕获该类异常，不是稳定性证明。结果见 `evidence/proc-task/page-no-zygote/` 和 `page-trap-diag/`。绕过 zygote 没有解除卡顿，因此后续排查不能只盯 PID oracle 握手。

页面日志中的 `ChildThreadImpl::EnsureConnected()` 不是连接成功提示。固定版本 `content/child/child_thread_impl.cc:908–910` 在打印后主动以状态 0 退出；`:115` 设置默认 15 秒，`:741–760` 注册定时检查，`:811–812 OnChannelConnected()` 取消它。非 legacy IPC 分支以 `Ping` 的回复确认连接。已有日志因此证明至少部分子进程已经走到 ChildThreadImpl 的连接阶段，随后未及时完成握手。

`--ipc-connection-timeout=120` 是进一步区分 TCG 启动延迟与实际通信问题的诊断参数；固定版本 `render_process_host_impl.cc:3601` 确认会转发给 renderer。它本身不修复 IPC，也没有证明 utility 子进程一定继承相同超时。下一步如仍失败，应围绕具体子进程有限记录 Mojo channel 的 sendmsg/recvmsg、FD 交接、epoll readiness 和连接回调，避免用“进程还在”代替链路完成。

## 最终页面验收：HTML/CSS/JS/Canvas 通过

最终实验 `page-timeout120/` 使用当前重新构建的普通内核，保留 zygote，并在前述软件绘制参数上增加 `--ipc-connection-timeout=120`。为减少本地页面测试中的后台请求，额外使用 `--disable-background-networking --disable-component-update`；它们不是内核功能修复。该实验完整结束、采集 12 帧，日志未出现 EnsureConnected 超时退出。

第 10 帧显示标题 `X-kernel Chromium test`、红绿蓝 CSS 网格、JavaScript ticks: 76 和 Canvas 绿色方块；第 12 帧计数增至 107，方块位置发生变化。此结果验证了本地文件导航、HTML 布局、CSS 网格、JavaScript 定时执行及 Canvas 绘制更新，不只是浏览器外框。

![第10帧：JavaScript计数76](evidence/proc-task/page-timeout120/chromium-10.png)

![第12帧：JavaScript计数107，Canvas位置变化](evidence/proc-task/page-timeout120/chromium-12.png)

### 当前已验证的客体启动方式

Weston 已启动，且 `XDG_RUNTIME_DIR` / `WAYLAND_DISPLAY` 与实际 socket 一致时，在 `kylin-x:~#` 使用：

```sh
chromium --ozone-platform=wayland --no-sandbox \
  --disable-gpu --disable-software-rasterizer \
  --ipc-connection-timeout=120 \
  --disable-background-networking --disable-component-update \
  --user-data-dir=/tmp/chromium-page-test --no-first-run \
  --enable-logging=stderr file:///tmp/xkernel-smoke.html \
  > /tmp/chromium-page-test.log 2>&1 &
```

`--ipc-connection-timeout=120` 将子进程连接 watchdog 的诊断容限从默认 15 秒扩至 120 秒；它不会让网站请求一律等待 120 秒。测试页源码在 `evidence/proc-task/page-smoke/smoke.html`，示例中的客体 `/tmp/xkernel-smoke.html` 由测试脚本在磁盘快照中创建，退出 QEMU 后不留在你的工作镜像中。使用正式测试页时换成它在客体里的实际 file URL。其余参数及 shell 重定向已在前文解释。

这组结果支持“当前跨架构模拟环境中启动时间影响连接 watchdog”的判断，但尚未给出严格同并发负载的耗时分布，也未实现新的 Mojo 语义修复；请保留这个推断边界。`--no-sandbox` 是现阶段调试条件，不能作为比赛沙箱安全验收。

最终结论：**本轮最小网页功能测试通过；组委会正式测试集、输入设备、完整硬件图形栈、性能和长期稳定性尚未验收。** 下一阶段应保存当前可运行配置，逐项运行正式测试页并记录通过/失败及资源占用。
