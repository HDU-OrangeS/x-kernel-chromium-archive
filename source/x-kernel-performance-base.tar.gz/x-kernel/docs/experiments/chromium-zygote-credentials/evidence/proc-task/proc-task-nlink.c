#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
static int ready, release_threads, failures, checks;
static void check_count(const char *name, int result, const struct stat *st, unsigned long want) {
    checks++;
    if (result != 0 || (unsigned long)st->st_nlink != want) {
        fprintf(stderr, "FAIL %s: result=%d errno=%d nlink=%lu expected=%lu\n", name, result, errno, (unsigned long)st->st_nlink, want);
        failures++;
    } else {
        printf("PASS %s: nlink=%lu\n", name, want);
    }
}
static void check_views(int taskfd, int procfd, const char *numeric, unsigned long want) {
    struct stat st = {0};
    int rc = fstat(taskfd, &st);
    check_count("same opened task directory fstat", rc, &st, want);
    rc = fstatat(procfd, "self/task/", &st, 0);
    check_count("Chromium fstatat self/task/", rc, &st, want);
    rc = stat("/proc/self/task", &st);
    check_count("stat self/task", rc, &st, want);
    rc = stat(numeric, &st);
    check_count("stat numeric pid/task", rc, &st, want);
}
static void *worker(void *unused) {
    (void)unused;
    pthread_mutex_lock(&lock);
    ready++;
    pthread_cond_broadcast(&cond);
    while (!release_threads) pthread_cond_wait(&cond, &lock);
    pthread_mutex_unlock(&lock);
    return NULL;
}
int main(void) {
    setbuf(stdout, NULL);
    alarm(20);
    int procfd = open("/proc", O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    int taskfd = open("/proc/self/task", O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    if (procfd < 0 || taskfd < 0) { perror("open proc task"); return 2; }
    char numeric[80];
    snprintf(numeric, sizeof(numeric), "/proc/%ld/task", (long)getpid());
    check_views(taskfd, procfd, numeric, 3);
    pthread_t threads[2];
    for (int i = 0; i < 2; i++) {
        int err = pthread_create(&threads[i], NULL, worker, NULL);
        if (err) { fprintf(stderr, "pthread_create: %d\n", err); return 2; }
        pthread_mutex_lock(&lock);
        while (ready != i + 1) pthread_cond_wait(&cond, &lock);
        pthread_mutex_unlock(&lock);
        check_views(taskfd, procfd, numeric, 4 + (unsigned long)i);
    }
    pthread_mutex_lock(&lock);
    release_threads = 1;
    pthread_cond_broadcast(&cond);
    pthread_mutex_unlock(&lock);
    for (int i = 0; i < 2; i++) {
        int err = pthread_join(threads[i], NULL);
        if (err) { fprintf(stderr, "pthread_join: %d\n", err); return 2; }
    }
    // Thread exit publication may trail the userspace completion notification.
    for (int i = 0; i < 2000; i++) {
        struct stat st;
        if (fstat(taskfd, &st) == 0 && st.st_nlink == 3) break;
        usleep(1000);
    }
    check_views(taskfd, procfd, numeric, 3);
    pid_t child = fork();
    if (child < 0) { perror("fork"); return 2; }
    if (child == 0) {
        struct stat st;
        _exit(fstatat(procfd, "self/task/", &st, 0) == 0 && st.st_nlink == 3 ? 0 : 1);
    }
    int status;
    if (waitpid(child, &status, 0) != child) { perror("waitpid"); return 2; }
    checks++;
    if (!WIFEXITED(status) || WEXITSTATUS(status) != 0) { fprintf(stderr, "FAIL forked child self/task links: status=%d\n", status); failures++; }
    else puts("PASS forked child self/task links");
    close(taskfd);
    close(procfd);
    printf("proc-task-nlink: %d checks, %d failures\n", checks, failures);
    return failures ? 1 : 0;
}
