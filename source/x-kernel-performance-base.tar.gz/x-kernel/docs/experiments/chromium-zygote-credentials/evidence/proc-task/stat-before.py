from pathlib import Path
import os, json, socket, time, pexpect
root=Path('/tmp/xkernel-gpu/proc-task')
qmp_path=str(root/'weston-qmp.sock')
args=['-m','2g','-smp','4','-cpu','cortex-a76','-machine','virt,gic-version=3',
 '-kernel','/tmp/xkernel-gpu/fixed/fixed-root/xkernel_aarch64-qemu.bin',
 '-device','virtio-blk-pci,drive=disk0','-drive','id=disk0,if=none,format=raw,file=/home/cuizh/x-kernel/disk.img',
 '-snapshot','-object','rng-random,id=host_rng0','-device','virtio-rng-pci,rng=host_rng0','-device','virtio-gpu-pci','-vga','none','-display','none','-serial','stdio','-monitor','none',
 '-qmp',f'unix:{qmp_path},server=on,wait=off','-device','virtio-keyboard-pci','-device','virtio-tablet-pci']
env=dict(os.environ)
for key in ['GTK_PATH','GIO_MODULE_DIR']: env.pop(key,None)
(root/'weston-qemu-args.json').write_text(json.dumps(args,indent=2))
log=(root/'weston-fresh-boot.log').open('w')
child=pexpect.spawn('qemu-system-aarch64',args,env=env,encoding='utf-8',timeout=45,maxread=65536)
child.logfile=log
qmp=None
try:
 child.expect('kylin-x:~# ')
 def run(cmd):
  child.sendline(cmd+(' ' if cmd.rstrip().endswith('&') else '; ')+'printf "\\n__CHECK_DONE:%s__\\n" "$?"')
  child.expect(r'\r\n__CHECK_DONE:(\d+)__')
  rc=int(child.match.group(1)); output=child.before
  child.expect('kylin-x:~# ')
  if rc: raise RuntimeError(f'guest command failed ({rc}): {cmd}\n{output}')
  return output
 run("stat -c '%h %n' /proc/self/task; ls -la /proc/self/task")
 print('Baseline proc task stat complete.')

finally:
 if qmp: qmp.close()
 child.terminate(force=True)
 log.close()
