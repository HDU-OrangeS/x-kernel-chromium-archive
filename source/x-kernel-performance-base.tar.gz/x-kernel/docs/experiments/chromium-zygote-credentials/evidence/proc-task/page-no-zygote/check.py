from pathlib import Path
import os, json, socket, time, pexpect
root=Path('/tmp/xkernel-gpu/proc-task/page-no-zygote')
qmp_path=str(root/'weston-qmp.sock')
args=['-m','2g','-smp','4','-cpu','cortex-a76','-machine','virt,gic-version=3',
 '-kernel',str(root/'fixed-root/xkernel_aarch64-qemu.bin'),
 '-device','virtio-blk-pci,drive=disk0','-drive','id=disk0,if=none,format=raw,file=/home/cuizh/x-kernel/disk.img',
 '-snapshot','-object','rng-random,id=host_rng0','-device','virtio-rng-pci,rng=host_rng0','-device','virtio-gpu-pci','-vga','none','-display','none','-serial','stdio','-monitor','none',
 '-qmp',f'unix:{qmp_path},server=on,wait=off','-device','virtio-keyboard-pci','-device','virtio-tablet-pci']
env=dict(os.environ)
for key in ['GTK_PATH','GIO_MODULE_DIR']: env.pop(key,None)
(root/'weston-qemu-args.json').write_text(json.dumps(args,indent=2))
log=(root/'weston-fresh-boot.log').open('w')
child=pexpect.spawn('qemu-system-aarch64',args,env=env,encoding='utf-8',timeout=45,maxread=65536)
child.logfile=log
qmp=None
try:
 child.expect('kylin-x:~# ')
 def run(cmd):
  child.sendline(cmd+(' ' if cmd.rstrip().endswith('&') else '; ')+'printf "\\n__CHECK_DONE:%s__\\n" "$?"')
  child.expect(r'\r\n__CHECK_DONE:(\d+)__')
  rc=int(child.match.group(1)); output=child.before
  child.expect('kylin-x:~# ')
  if rc: raise RuntimeError(f'guest command failed ({rc}): {cmd}\n{output}')
  return output
 run('ps; cat /sys/class/drm/card0/dev; cat /sys/class/drm/card0/uevent')
 run('command -v weston; command -v seatd; command -v weston-simple-shm')
 run('export XDG_RUNTIME_DIR=/run/user/0; mkdir -p "$XDG_RUNTIME_DIR"; chmod 700 "$XDG_RUNTIME_DIR"')
 run('SEATD_VTBOUND=0 seatd -g root -l debug > /tmp/seatd-permanent.log 2>&1 &')
 run('sleep 1; pidof seatd')
 run('LIBSEAT_BACKEND=seatd SEATD_SOCK=/run/seatd.sock weston --backend=drm --renderer=pixman --drm-device=card0 --continue-without-input --idle-time=0 --log=/tmp/weston-permanent.log > /tmp/weston-permanent-stderr.log 2>&1 &')
 run('sleep 4; cat /tmp/weston-permanent.log; cat /tmp/weston-permanent-stderr.log; pidof weston')
 run('for sock in "$XDG_RUNTIME_DIR"/wayland-*; do if [ -S "$sock" ]; then export WAYLAND_DISPLAY="${sock##*/}"; break; fi; done; test -n "$WAYLAND_DISPLAY"; echo "$WAYLAND_DISPLAY"')
 run('printf %s PCFkb2N0eXBlIGh0bWw+PG1ldGEgY2hhcnNldD0idXRmLTgiPjx0aXRsZT5YLWtlcm5lbCByZW5kZXIgdGVzdDwvdGl0bGU+CjxzdHlsZT5ib2R5e2ZvbnQ6MjRweCBzYW5zLXNlcmlmO2JhY2tncm91bmQ6I2VhZjFmYjtwYWRkaW5nOjM1cHg7Y29sb3I6IzE1MzQ1Mn1hcnRpY2xle2JhY2tncm91bmQ6d2hpdGU7cGFkZGluZzoyOHB4O2JvcmRlcjo2cHggc29saWQgIzFiOTg2MH1oMXtjb2xvcjojMTY4MjU0fS5ncmlke2Rpc3BsYXk6Z3JpZDtncmlkLXRlbXBsYXRlLWNvbHVtbnM6cmVwZWF0KDMsMTUwcHgpO2dhcDoxMnB4fS5ncmlkIGRpdntoZWlnaHQ6OTBweDtkaXNwbGF5OmdyaWQ7cGxhY2UtaXRlbXM6Y2VudGVyO2NvbG9yOndoaXRlfSNjb3VudGVye2ZvbnQtc2l6ZTozMnB4fTwvc3R5bGU+CjxhcnRpY2xlPjxoMT5YLWtlcm5lbCBDaHJvbWl1bSB0ZXN0PC9oMT48cD5IVE1MIGFuZCBDU1MgcmVuZGVyZWQgc3VjY2Vzc2Z1bGx5LjwvcD48ZGl2IGNsYXNzPSJncmlkIj48ZGl2IHN0eWxlPSJiYWNrZ3JvdW5kOiNkYjRlNGUiPlJFRDwvZGl2PjxkaXYgc3R5bGU9ImJhY2tncm91bmQ6IzFiOTg2MCI+R1JFRU48L2Rpdj48ZGl2IHN0eWxlPSJiYWNrZ3JvdW5kOiMzZDZkZTAiPkJMVUU8L2Rpdj48L2Rpdj48cCBpZD0iY291bnRlciI+SmF2YVNjcmlwdCBoYXMgbm90IHJ1bjwvcD48Y2FudmFzIGlkPSJjYW52YXMiIHdpZHRoPSI0NTAiIGhlaWdodD0iNzAiPjwvY2FudmFzPjwvYXJ0aWNsZT4KPHNjcmlwdD5sZXQgY291bnQ9MDtmdW5jdGlvbiB0aWNrKCl7ZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI2NvdW50ZXInKS50ZXh0Q29udGVudD0nSmF2YVNjcmlwdCB0aWNrczogJysoKytjb3VudCk7Y29uc3QgYz1kb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjY2FudmFzJykuZ2V0Q29udGV4dCgnMmQnKTtjLmZpbGxTdHlsZT0nI2RjZTRmMCc7Yy5maWxsUmVjdCgwLDAsNDUwLDcwKTtjLmZpbGxTdHlsZT0nIzFiOTg2MCc7Yy5maWxsUmVjdCgoY291bnQqMTUpJTQwMCwxMCw1MCw1MCl9dGljaygpO3NldEludGVydmFsKHRpY2ssMTAwMCk7PC9zY3JpcHQ+ | base64 -d > /tmp/xkernel-smoke.html')
 run('chromium --ozone-platform=wayland --no-sandbox --no-zygote --disable-gpu --disable-software-rasterizer --user-data-dir=/tmp/chromium-nnp-validation --no-first-run --disable-background-networking --disable-component-update --enable-logging=stderr --v=1 file:///tmp/xkernel-smoke.html > /tmp/chromium-nnp.log 2>&1 &')
 run('sleep 15; ps; tail -n 60 /tmp/chromium-nnp.log')
 qmp=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM); qmp.settimeout(5); qmp.connect(qmp_path)
 stream=qmp.makefile('rwb',buffering=0)
 def receive():
  while True:
   response=json.loads(stream.readline())
   if 'return' in response: return response['return']
   if 'error' in response: raise RuntimeError(response)
 stream.readline()
 def execute(command,arguments=None):
  message={'execute':command}
  if arguments: message['arguments']=arguments
  stream.write((json.dumps(message)+'\n').encode()); return receive()
 execute('qmp_capabilities')
 for i in range(1, 11):
  execute('screendump',{'filename':str(root/f'chromium-{i}.ppm')})
  run('ps; tail -n 80 /tmp/chromium-nnp.log')
  if i < 10: run('sleep 15')
 run('cat /tmp/chromium-nnp.log; cat /tmp/weston-permanent.log')
 print('Observation finished: inspect screenshots and logs; process existence alone is not browser success.')

finally:
 if qmp: qmp.close()
 child.terminate(force=True)
 log.close()
