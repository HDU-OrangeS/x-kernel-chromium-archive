from pathlib import Path
import subprocess,re,json
root=Path('/tmp/xkernel-gpu/proc-task')
args=['qemu-system-aarch64','-m','2g','-smp','4','-cpu','cortex-a76','-machine','virt,gic-version=3','-kernel',str(root/'kernel-unit.bin'),'-device','virtio-blk-pci,drive=disk0','-drive','id=disk0,if=none,format=raw,file=/home/cuizh/x-kernel/disk.img','-snapshot','-nic','none','-nographic']
(root/'unit-qemu-args.json').write_text(json.dumps(args,indent=2))
with (root/'unit-run.log').open('w') as log:
    p=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT)
    try: p.wait(timeout=90)
    except subprocess.TimeoutExpired:
        p.terminate(); p.wait(timeout=10)
text=(root/'unit-run.log').read_text()
match=re.search(r'Test results: (\d+) passed, (\d+) failed, (\d+) ignored, (\d+) total',text)
if not match: raise SystemExit('No unit summary, inspect log')
print(match.group())
assert int(match[2])==0 and int(match[4])>0
assert 'RESULT posix_net::cmsg::tests::test_unix_credentials_encode_all_identity_fields ... ok' in text
