# Chromium 142 GPU 子进程启动失败源码核对

日期：2026-10-03。只读分析，不修改项目代码，不安装依赖，不启动 QEMU。

## 版本与证据边界

主任务从用户 `disk.img` 的 APK installed 数据确认 Chromium 为 `142.0.7444.59-r0`、aarch64。本分析读取 Chromium 官方 GitHub 镜像的上游 `142.0.7444.59` tag；不是以最新 main 推断旧版本。Google Gitiles 对应 tag 在网页工具中不可访问，随后通过官方仓库 raw URL 读取。尚未比对 Alpine 包补丁全集，因此结论严格对应同版本上游源码；用户日志 `gpu_process_host.cc:993`、`zygote_main_linux.cc:201` 与该版本匹配。

原始源码保存在本目录旁 `chromium-source-142.0.7444.59/`，文件 URL、字节数和 SHA-256 见其中 `manifest.json`。下文所有行号针对这些文件。

## 已确定：1002 不是 GPU 驱动错误号

`1002` 是 Chromium 的 `LAUNCH_RESULT_SUCCESS` 枚举值，`1003` 才是通用启动失败。这个看似矛盾的失败日志源于 Linux zygote 分支：调用 `ForkRequest` 后无条件把 launch_result 置为 success，即使返回了空进程句柄。最后通知层实际按进程句柄 `IsValid()` 选择成功/失败回调，于是可能发生 `OnProcessLaunchFailed(1002)`。

[content/browser/child_process_launcher.h:70–78](https://github.com/chromium/chromium/blob/142.0.7444.59/content/browser/child_process_launcher.h#L70-L78)

```cpp
70: // Note: These codes are listed in a histogram and any new codes should be added
71: // at the end.
72: enum LaunchResultCode {
73:   // Launch start code, to not overlap with sandbox::ResultCode.
74:   LAUNCH_RESULT_START = 1001,
75:   // Launch success.
76:   LAUNCH_RESULT_SUCCESS,
77:   // Generic launch failure.
78:   LAUNCH_RESULT_FAILURE,
```

[content/browser/child_process_launcher_helper_linux.cc:85–95](https://github.com/chromium/chromium/blob/142.0.7444.59/content/browser/child_process_launcher_helper_linux.cc#L85-L95)

```cpp
85:   Process process;
86:   ZygoteCommunication* zygote_handle = GetZygoteForLaunch();
87:   if (zygote_handle) {
88:     // TODO(crbug.com/40448989): If chrome supported multiple zygotes they could
89:     // be created lazily here, or in the delegate GetZygote() implementations.
90:     // Additionally, the delegate could provide a UseGenericZygote() method.
91:     base::ProcessHandle handle = zygote_handle->ForkRequest(
92:         command_line()->argv(), files_to_register->GetMapping(),
93:         GetProcessType());
94:     *launch_result = LAUNCH_RESULT_SUCCESS;
95: 
```

[content/browser/child_process_launcher_helper_linux.cc:107–113](https://github.com/chromium/chromium/blob/142.0.7444.59/content/browser/child_process_launcher_helper_linux.cc#L107-L113)

```cpp
107:     process.process = base::Process(handle);
108:     process.zygote = zygote_handle;
109:   } else {
110:     process.process = base::LaunchProcess(*command_line(), *options);
111:     *launch_result = process.process.IsValid() ? LAUNCH_RESULT_SUCCESS
112:                                                : LAUNCH_RESULT_FAILURE;
113:   }
```

[content/browser/child_process_launcher.cc:209–220](https://github.com/chromium/chromium/blob/142.0.7444.59/content/browser/child_process_launcher.cc#L209-L220)

```cpp
209:     // Note:: May delete |this|.
210:     client_->OnProcessLaunched();
211:   } else {
212:     termination_info_.status = base::TERMINATION_STATUS_LAUNCH_FAILED;
213:     termination_info_.exit_code = error_code;
214: #if BUILDFLAG(IS_WIN)
215:     termination_info_.last_error = last_error;
216: #endif
217: 
218:     // NOTE: May delete |this|.
219:     client_->OnProcessLaunchFailed(error_code);
220:   }
```

相反，直接 `base::LaunchProcess` 分支会根据 `IsValid()` 设置 1002 或 1003。在对应源码未被发行版更改的前提下，当前日志把问题明确收窄到 zygote 的 ForkRequest 失败，而不是在 GPU 初始化完成后崩溃。`GpuProcessHost::OnProcessCrashed` 的另外一条消息是 `GPU process exited unexpectedly: exit_code=...`。

[content/browser/gpu/gpu_process_host.cc:992–1001](https://github.com/chromium/chromium/blob/142.0.7444.59/content/browser/gpu/gpu_process_host.cc#L992-L1001)

```cpp
992: void GpuProcessHost::OnProcessLaunchFailed(int error_code) {
993:   LOG(ERROR) << "GPU process launch failed: error_code=" << error_code;
994:   RecordProcessCrash();
995: }
996: 
997: void GpuProcessHost::OnProcessCrashed(int exit_code) {
998:   // Record crash before doing anything that could start a new GPU process.
999:   LOG(ERROR) << "GPU process exited unexpectedly: exit_code=" << exit_code;
1000:   RecordProcessCrash();
1001:   gpu_host_->OnProcessCrashed();
```

## zygote 启动与 PID 握手链

```mermaid
sequenceDiagram
    participant B as 浏览器 launcher
    participant Z as zygote
    participant C as GPU 子进程
    participant K as 内核 Unix socket
    B->>K: socketpair(AF_UNIX, SOCK_SEQPACKET)
    B->>K: 接收端 setsockopt(SO_PASSCRED, 1)
    B->>Z: Fork 请求 + SCM_RIGHTS（PID oracle 和其他 FD）
    Z->>C: fork
    C->>K: 向继承的 PID oracle FD 发送 ping
    K-->>B: ping 普通数据 + SCM_CREDENTIALS（发送进程 PID）
    B->>Z: ForkRealPID(real_pid)
    alt real_pid 正确且其他步骤成功
        Z->>C: 管道写回 real_pid
        Z-->>B: ForkReply(child_pid)
        B->>B: 有效句柄：OnProcessLaunched
    else real_pid 小于 0
        Z->>C: KillAndReap
        Z-->>B: ForkReply(-1)
        B->>B: 无效句柄：OnProcessLaunchFailed(1002)
    end
```

关键点：SO_PASSCRED 成功只是允许内核给后续接收消息附加凭据。真正识别 PID 的是 `recvmsg` 返回的 `SCM_CREDENTIALS`，不是 socket 创建时记录的 PID，也不是 `SO_PEERCRED`。PID oracle 的发送端在创建后经 FD 传递和 fork 到子进程，所以必须识别实际发送者。

[content/common/zygote/zygote_communication_linux.cc:102–107](https://github.com/chromium/chromium/blob/142.0.7444.59/content/common/zygote/zygote_communication_linux.cc#L102-L107)

```cpp
102:   base::Pickle pickle;
103:   int raw_socks[2];
104:   PCHECK(0 == socketpair(AF_UNIX, SOCK_SEQPACKET, 0, raw_socks));
105:   base::ScopedFD my_sock(raw_socks[0]);
106:   base::ScopedFD peer_sock(raw_socks[1]);
107:   CHECK(base::UnixDomainSocket::EnableReceiveProcessId(my_sock.get()));
```

[content/common/zygote/zygote_communication_linux.cc:149–169](https://github.com/chromium/chromium/blob/142.0.7444.59/content/common/zygote/zygote_communication_linux.cc#L149-L169)

```cpp
149:       char buf[sizeof(kZygoteChildPingMessage) + 1];
150:       std::vector<base::ScopedFD> recv_fds;
151:       base::ProcessId real_pid;
152: 
153:       ssize_t n = base::UnixDomainSocket::RecvMsgWithPid(
154:           my_sock.get(), buf, sizeof(buf), &recv_fds, &real_pid);
155:       if (n != sizeof(kZygoteChildPingMessage) ||
156:           0 != UNSAFE_TODO(memcmp(buf, kZygoteChildPingMessage,
157:                                   sizeof(kZygoteChildPingMessage)))) {
158:         // Zygote children should still be trustworthy when they're supposed to
159:         // ping us, so something's broken if we don't receive a valid ping.
160:         DUMP_WILL_BE_NOTREACHED() << "Did not receive ping from zygote child";
161:         real_pid = -1;
162:       }
163:       my_sock.reset();
164: 
165:       // Always send PID back to zygote.
166:       base::Pickle pid_pickle;
167:       pid_pickle.WriteInt(kZygoteCommandForkRealPID);
168:       pid_pickle.WriteInt(real_pid);
169:       if (!SendMessage(pid_pickle, nullptr))
```

[base/posix/unix_domain_socket.cc:49–55](https://github.com/chromium/chromium/blob/142.0.7444.59/base/posix/unix_domain_socket.cc#L49-L55)

```cpp
49: bool UnixDomainSocket::EnableReceiveProcessId(int fd) {
50: #if !BUILDFLAG(IS_APPLE)
51:   const int enable = 1;
52:   return setsockopt(fd, SOL_SOCKET, SO_PASSCRED, &enable, sizeof(enable)) == 0;
53: #else
54:   // SO_PASSCRED is not supported on macOS.
55:   return true;
```

[base/posix/unix_domain_socket.cc:151–154](https://github.com/chromium/chromium/blob/142.0.7444.59/base/posix/unix_domain_socket.cc#L151-L154)

```cpp
151:   int* wire_fds = nullptr;
152:   size_t wire_fds_len = 0;
153:   ProcessId pid = -1;
154: 
```

[base/posix/unix_domain_socket.cc:165–173](https://github.com/chromium/chromium/blob/142.0.7444.59/base/posix/unix_domain_socket.cc#L165-L173)

```cpp
165: #if !BUILDFLAG(IS_APPLE)
166:       // macOS does not support SCM_CREDENTIALS.
167:       if (cmsg->cmsg_level == SOL_SOCKET &&
168:           cmsg->cmsg_type == SCM_CREDENTIALS) {
169:         DCHECK_EQ(payload_len, sizeof(struct ucred));
170:         DCHECK_EQ(pid, -1);
171:         pid = reinterpret_cast<struct ucred*>(CMSG_DATA(cmsg))->pid;
172:       }
173: #endif  // !BUILDFLAG(IS_APPLE)
```

[base/posix/unix_domain_socket.cc:203–212](https://github.com/chromium/chromium/blob/142.0.7444.59/base/posix/unix_domain_socket.cc#L203-L212)

```cpp
203:     // |pid| will legitimately be -1 if we read EOF, so only DCHECK if we
204:     // actually received a message.  Unfortunately, Linux allows sending zero
205:     // length messages, which are indistinguishable from EOF, so this check
206:     // has false negatives.
207:     if (r > 0 || msg.msg_controllen > 0) {
208:       DCHECK_GE(pid, 0);
209:     }
210: #endif
211: 
212:     *out_pid = pid;
```

[content/zygote/zygote_linux.cc:513–517](https://github.com/chromium/chromium/blob/142.0.7444.59/content/zygote/zygote_linux.cc#L513-L517)

```cpp
513:   // If we successfully forked a child, but it crashed without sending
514:   // a message to the browser, the browser won't have found its PID.
515:   if (real_pid < 0) {
516:     KillAndReap(pid, helper);
517:     return -1;
```

[content/common/zygote/zygote_communication_linux.cc:205–210](https://github.com/chromium/chromium/blob/142.0.7444.59/content/common/zygote/zygote_communication_linux.cc#L205-L210)

```cpp
205:     if (pid <= 0)
206:       return base::kNullProcessHandle;
207:   }
208: 
209:   ZygoteChildBorn(pid);
210:   return pid;
```

在 release 构建中，缺少 SCM_CREDENTIALS 的检查主要是 DCHECK；可以收到正确普通数据，但 `pid` 仍为初始值 -1。于是 ping 内容检查通过，浏览器仍把 -1 回给 zygote，后者杀死已 fork 的子进程并报告失败。它解释了为何通常看不到更直白的“凭据缺失”日志。

此外，ForkRequest 还有别的空句柄返回路径：向 zygote 发送请求失败、向 zygote 发送 real PID 失败、读回复失败/解析失败、回复 PID 非正。因此 1002 本身不能唯一证明 SCM_CREDENTIALS 是根因，仍需小探针和修复前后对照。

## 与当前 x-kernel 的对照

本次只读查看确认：

- `/home/cuizh/x-kernel/net/knet/src/unix/dgram.rs:119` 和 `:139`：PassCredentials 的 get/set 分支均为空操作。
- `/home/cuizh/x-kernel/net/knet/src/unix/stream.rs:88` 和 `:110`：同样为空操作。
- `/home/cuizh/x-kernel/posix/net/src/cmsg.rs:149` 开始的 CMsg 只有 Rights，没有 SCM_CREDENTIALS 分支；`posix/net/src/io.rs` 当前接收导出的是 SCM_RIGHTS。

以上位置是读取时状态，之后主任务会修改，最终报告需更新行号。SO_PASSCRED 不保存状态、recvmsg 不生成凭据，与 Chromium PID oracle 的契约直接冲突。这是代码层已确认缺口；Chromium 故障是否完全由它造成仍需回归。

此前实际日志 `/tmp/xkernel-nnp/weston-fresh-boot.log:987` 报过 crashpad `socket.cc:177 missing credentials`。它发生在 GPU fatal 之后，只能作为旁证，不能用它替代第一次失败的因果证据。

## 最小分支实验与验收

1. 在不改其他参数的前提下给已有诊断命令添加 `--no-zygote`。该开关令 GetZygoteForLaunch 直接返回 nullptr，切到 base::LaunchProcess 分支。仍保留既有 `--no-sandbox`，不同时修改渲染器/内存/图形环境。
2. 观察“1002 失败是否消失”、子进程是否得到有效 PID、随后首条新错误，而不能只观察浏览器进程是否存活。用户窗口还没出现也可能已经越过当前故障。
3. 小探针在 Linux 宿主和 x-kernel 客体分别创建 AF_UNIX/SOCK_SEQPACKET 的 socketpair，接收端设置 SO_PASSCRED；fork 子进程发送 ping；父进程 recvmsg，校验 SCM_CREDENTIALS 的 PID 等于子进程、UID/GID 是发送时凭据。另对 SOCK_DGRAM 和 STREAM 做契约测试。
4. 再做含 SCM_RIGHTS 的消息，要求 RIGHTS 和 CREDENTIALS 同时到达；区分控制区不足的 MSG_CTRUNC，显式发送凭据时按 Linux 权限规则校验 PID/UID/GID（具备相应 capability 的调用者存在合法例外），不以返回固定 PID 或固定 root 凭据通过测试。
5. 修复后恢复原始 zygote 启动路径，不保留 `--no-zygote` 作为“修复”。GPU/renderer/utility 子进程的有效 PID、实际浏览器窗口和页面绘制分别验收。

主任务截至本报告写入时反馈：`--no-zygote` 对照暂未再报 GPU fatal，但仍未见浏览器窗口。此状态不是完整成功，不把它写成已修复。

[content/browser/child_process_launcher_helper_linux.cc:184–188](https://github.com/chromium/chromium/blob/142.0.7444.59/content/browser/child_process_launcher_helper_linux.cc#L184-L188)

```cpp
184: ZygoteCommunication* ChildProcessLauncherHelper::GetZygoteForLaunch() {
185:   return base::CommandLine::ForCurrentProcess()->HasSwitch(switches::kNoZygote)
186:              ? nullptr
187:              : delegate_->GetZygote();
188: }
```

## 文件校验

| 文件 | SHA-256 |
| --- | --- |

| `content/browser/child_process_launcher.h` | `42f62e0746676d59a4ab04273610141be904c9ae184526a3e4cae8bedfb248f6` |

| `content/browser/child_process_launcher_helper_linux.cc` | `32d71d2512925e8419c6bc0a8bccd8b422acb70684840f3b852dfda3d40b102c` |

| `content/browser/child_process_launcher.cc` | `2e87ddea8747a5595db9cd2d3778f8293c03b999b6d5a1ef5360028f2f25fdc9` |

| `content/browser/gpu/gpu_process_host.cc` | `b8c200a380d61058bddeaa024922cfbae1493502d1319c80785f28839fcd2980` |

| `content/common/zygote/zygote_communication_linux.cc` | `93703ad7216739344041d9db648a357e248906f0d9084e161b20792234b96abe` |

| `base/posix/unix_domain_socket.cc` | `04b1295cdcd638e92f627103b965d10405cd800d9bf1ff4771c92cfb7fbc9cb9` |

| `content/zygote/zygote_linux.cc` | `e5ea9f54d629a10d501441d0fc125fde0b8764bb3320d14b19618efc49255c07` |
