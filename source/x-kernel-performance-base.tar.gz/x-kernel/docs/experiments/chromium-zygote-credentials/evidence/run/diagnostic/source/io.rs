// SPDX-License-Identifier: Apache-2.0
// Copyright 2025 KylinSoft Co., Ltd. <https://www.kylinos.cn/>
// See LICENSES for license details.

//! Network I/O syscalls.
//!
//! This module implements network I/O operations including:
//! - Send and receive (send, recv, sendto, recvfrom, etc.)
//! - Vectored I/O (sendmsg, recvmsg, etc.)
//! - Out-of-band data handling
//! - Ancillary data (control messages)

use alloc::{sync::Arc, vec::Vec};
use core::net::Ipv4Addr;

use kerrno::{KError, KResult, LinuxError};
use khal::time::monotonic_time;
use kio::prelude::*;
use knet::{
    AncillaryData, KernelAncillaryData, RecvFlags, RecvOptions, SendFlags, SendOptions, Socket,
    SocketAddrEx, SocketErrorInfo, SocketOps, sock_from_file,
};
use ktime_types::TimeSpan;
use kvfs::VfsFile;
use linux_raw_sys::{
    general::timespec,
    net::{
        MSG_CMSG_CLOEXEC, MSG_CTRUNC, MSG_DONTWAIT, MSG_ERRQUEUE, MSG_PEEK, MSG_TRUNC, SCM_RIGHTS,
        SOL_SOCKET, cmsghdr, mmsghdr, msghdr, sockaddr, socklen_t,
    },
};
use osvm::{VirtPtr, VmBytes, VmBytesMut, write_vm_mem};
use posix_types::{IoVec, IoVectorBuf, TimeSpanLike, UserConstPtr, UserPtr};

use crate::{
    addr::SocketAddrExt,
    cmsg::{
        CMsg, CMsgBuilder, MAX_RIGHTS_FDS, cmsg_align, push_ip_recverr_cmsg,
        push_unix_credentials_cmsg,
    },
};

// Linux ABI for sendmmsg/recvmmsg limits vlen to UIO_MAXIOV (1024).
const MMSG_MAX_VLEN: u32 = 1024;

fn parse_send_flags(flags: u32) -> SendFlags {
    let mut send_flags = SendFlags::empty();
    if flags & MSG_DONTWAIT != 0 {
        send_flags |= SendFlags::DONT_WAIT;
    }
    send_flags
}

fn parse_recvmmsg_timeout(timeout: UserConstPtr<timespec>) -> KResult<Option<TimeSpan>> {
    if timeout.is_null() {
        return Ok(None);
    }
    Ok(Some(timeout.read_vm()?.try_into_time_span()?))
}

fn parse_send_cmsgs(
    resources: &kresources::ProcessResources,
    control_ptr: usize,
    control_len: usize,
) -> KResult<Vec<AncillaryData>> {
    let mut ancillary = Vec::new();
    if control_ptr == 0 || control_len == 0 {
        return Ok(ancillary);
    }

    let mut files = Vec::new();
    let mut ptr = control_ptr;
    let ptr_end = ptr.checked_add(control_len).ok_or(KError::InvalidInput)?;

    while let Some(next) = ptr.checked_add(size_of::<cmsghdr>()) {
        if next > ptr_end {
            break;
        }

        let hdr_ptr = UserConstPtr::<cmsghdr>::from(ptr);
        let hdr = hdr_ptr.read_vm()?;
        if hdr.cmsg_len < size_of::<cmsghdr>() || ptr_end - ptr < hdr.cmsg_len {
            return Err(KError::InvalidInput);
        }

        let CMsg::Rights { fds } = CMsg::parse(resources, hdr_ptr, hdr)?;
        if files.len() + fds.len() > MAX_RIGHTS_FDS {
            return Err(KError::InvalidInput);
        }
        files.extend(fds);
        let step = cmsg_align(hdr.cmsg_len).ok_or(KError::InvalidInput)?;
        let Some(next) = ptr.checked_add(step) else {
            break;
        };
        ptr = next;
    }

    // Linux combines all SCM_RIGHTS headers from one sendmsg into one list.
    if !files.is_empty() {
        ancillary.push(Arc::new(CMsg::Rights { fds: files }) as AncillaryData);
    }
    Ok(ancillary)
}

enum SocketAncillary {
    Rights { fds: Vec<Arc<VfsFile>> },
    IpError(SocketErrorInfo),
    UnixCredentials(knet::options::UnixCredentials),
}

fn into_socket_ancillary(ancillary: &AncillaryData) -> Option<SocketAncillary> {
    // Peeking must leave the queued file references intact while each receive
    // allocates a distinct set of receiver-local descriptors.
    if let Some(ancillary) = ancillary.downcast_ref::<CMsg>() {
        return Some(match ancillary {
            CMsg::Rights { fds } => SocketAncillary::Rights { fds: fds.clone() },
        });
    }
    if let Some(ancillary) = ancillary.downcast_ref::<KernelAncillaryData>() {
        return Some(match ancillary {
            KernelAncillaryData::IpError(err) => SocketAncillary::IpError(err.clone()),
            KernelAncillaryData::UnixCredentials(cred) => {
                SocketAncillary::UnixCredentials(cred.clone())
            }
        });
    }
    None
}

fn push_socket_cmsg(
    builder: &mut CMsgBuilder<'_>,
    ancillary: SocketAncillary,
    install_file: &mut impl FnMut(Arc<VfsFile>) -> KResult<i32>,
) -> KResult<bool> {
    match ancillary {
        SocketAncillary::Rights { fds } => {
            if fds.is_empty() {
                return Ok(true);
            }
            let fd_count = fds.len();
            let body_len = fd_count
                .checked_mul(size_of::<i32>())
                .ok_or(KError::from(LinuxError::ENOBUFS))?;
            let mut installed_count = 0;
            let pushed = builder.push(SOL_SOCKET, SCM_RIGHTS, body_len, |data| {
                for (file, chunk) in fds.into_iter().zip(data.chunks_exact_mut(size_of::<i32>())) {
                    let fd = match install_file(file) {
                        Ok(fd) => fd,
                        Err(KError::TooManyOpenFiles) => break,
                        Err(err) => return Err(err),
                    };
                    chunk.copy_from_slice(&fd.to_ne_bytes());
                    installed_count += 1;
                }
                if installed_count == 0 {
                    return Err(KError::from(LinuxError::ENOBUFS));
                }
                Ok(installed_count * size_of::<i32>())
            })?;
            Ok(pushed && installed_count == fd_count)
        }
        SocketAncillary::IpError(err) => push_ip_recverr_cmsg(builder, err),
        SocketAncillary::UnixCredentials(cred) => push_unix_credentials_cmsg(builder, &cred),
    }
}

/// Send data on a socket with optional destination address and ancillary data
fn send_impl(
    fd: i32,
    mut src: impl Read + IoBuf,
    flags: u32,
    addr: UserConstPtr<sockaddr>,
    addrlen: socklen_t,
    ancillary: Vec<AncillaryData>,
) -> KResult<isize> {
    let addr = if addr.is_null() || addrlen == 0 {
        None
    } else {
        Some(SocketAddrEx::read_from_user(addr, addrlen)?)
    };

    debug!("sys_send <= fd: {fd}, flags: {flags}, addr: {addr:?}");

    let file = kprocess::current_resources().get_file(fd)?;
    let socket = sock_from_file(&file)?;
    let mut send_flags = parse_send_flags(flags);
    if file.is_nonblocking() {
        send_flags |= SendFlags::DONT_WAIT;
    }
    let options = SendOptions {
        to: addr,
        flags: send_flags,
        ancillary,
    };
    let sent = match socket.as_ref() {
        Socket::Netlink(_) => {
            let cred = kprocess::current_cred();
            socket.send_with_cred(&mut src, options, &cred)?
        }
        _ => socket.send(&mut src, options)?,
    };

    Ok(sent as isize)
}

/// Send data to a specific address on a socket
pub fn sys_sendto(
    fd: i32,
    buf: *const u8,
    len: usize,
    flags: u32,
    addr: UserConstPtr<sockaddr>,
    addrlen: socklen_t,
) -> KResult<isize> {
    send_impl(fd, VmBytes::new(buf, len), flags, addr, addrlen, Vec::new())
}

/// Send data with vectored I/O and ancillary data (control messages)
pub fn sys_sendmsg(fd: i32, msg: UserConstPtr<msghdr>, flags: u32) -> KResult<isize> {
    let msg = msg.read_vm()?;
    let resources = kprocess::current_resources();
    let ancillary = parse_send_cmsgs(
        resources.as_ref(),
        msg.msg_control as usize,
        msg.msg_controllen,
    )?;
    send_impl(
        fd,
        IoVectorBuf::from_iovecs(IoVec::load_from_user(
            posix_types::UserConstPtr::from(msg.msg_iov as usize),
            msg.msg_iovlen,
        )?)?
        .into_io(),
        flags,
        UserConstPtr::from(msg.msg_name as usize),
        msg.msg_namelen as socklen_t,
        ancillary,
    )
}

/// Destination for optional peer address metadata.
struct RecvOutput<'a> {
    addr: UserPtr<sockaddr>,
    addrlen: RecvAddrLen<'a>,
}

enum RecvAddrLen<'a> {
    User(UserPtr<socklen_t>),
    Value(&'a mut socklen_t),
}

impl RecvAddrLen<'_> {
    fn read(&self) -> KResult<socklen_t> {
        match self {
            RecvAddrLen::User(ptr) => ptr.read_vm().map_err(Into::into),
            RecvAddrLen::Value(value) => Ok(**value),
        }
    }

    fn write(&mut self, value: socklen_t) -> KResult<()> {
        match self {
            RecvAddrLen::User(ptr) => ptr.write_vm(value).map_err(Into::into),
            RecvAddrLen::Value(dst) => {
                **dst = value;
                Ok(())
            }
        }
    }
}

impl<'a> RecvOutput<'a> {
    fn new(addr: UserPtr<sockaddr>, addrlen: UserPtr<socklen_t>) -> Self {
        Self {
            addr,
            addrlen: RecvAddrLen::User(addrlen),
        }
    }
}

struct RecvResult {
    len: usize,
    flags: RecvFlags,
    ancillary: Vec<AncillaryData>,
}

fn recv_impl(
    fd: i32,
    mut dst: impl Write + IoBufMut,
    flags: u32,
    mut output: RecvOutput<'_>,
) -> KResult<RecvResult> {
    debug!("sys_recv <= fd: {fd}, flags: {flags}");

    let resources = kprocess::current_user_process().resources()?;
    let file = resources.get_file(fd)?;
    let socket = sock_from_file(&file)?;
    let mut recv_flags = RecvFlags::empty();
    if flags & MSG_PEEK != 0 {
        recv_flags |= RecvFlags::PEEK;
    }
    if flags & MSG_TRUNC != 0 {
        recv_flags |= RecvFlags::TRUNCATE;
    }
    if flags & MSG_ERRQUEUE != 0 {
        recv_flags |= RecvFlags::ERROR_QUEUE;
    }
    if file.is_nonblocking() || flags & MSG_DONTWAIT != 0 {
        recv_flags |= RecvFlags::DONT_WAIT;
    }

    let mut ancillary = Vec::new();
    let mut reported_flags = RecvFlags::empty();

    let mut remote_addr =
        (!output.addr.is_null()).then(|| SocketAddrEx::Ip((Ipv4Addr::UNSPECIFIED, 0).into()));
    let recv = socket.recv(
        &mut dst,
        RecvOptions {
            from: remote_addr.as_mut(),
            flags: recv_flags,
            ancillary: Some(&mut ancillary),
            out_flags: Some(&mut reported_flags),
        },
    )?;
    if let Some(remote_addr) = remote_addr {
        let mut addrlen_value = output.addrlen.read()?;
        remote_addr.write_to_user(output.addr, &mut addrlen_value)?;
        output.addrlen.write(addrlen_value)?;
    }

    debug!("sys_recv => fd: {fd}, recv: {recv}");
    Ok(RecvResult {
        len: recv,
        flags: reported_flags,
        ancillary,
    })
}

fn receive_control_messages(
    msg: &mut msghdr,
    ancillary: &[AncillaryData],
    install_file: &mut impl FnMut(Arc<VfsFile>) -> KResult<i32>,
) -> KResult<()> {
    if msg.msg_control.is_null() {
        msg.msg_controllen = 0;
        if !ancillary.is_empty() {
            msg.msg_flags |= MSG_CTRUNC;
        }
        return Ok(());
    }

    let mut builder = CMsgBuilder::new(
        UserPtr::from(msg.msg_control as *mut cmsghdr),
        &mut msg.msg_controllen,
    );
    for ancillary in ancillary {
        let Some(ancillary) = into_socket_ancillary(ancillary) else {
            warn!("received unexpected ancillary");
            continue;
        };
        match push_socket_cmsg(&mut builder, ancillary, install_file) {
            Ok(true) => {}
            Ok(false) => {
                msg.msg_flags |= MSG_CTRUNC;
                break;
            }
            Err(err) if err == KError::from(LinuxError::ENOBUFS) => {
                msg.msg_flags |= MSG_CTRUNC;
                break;
            }
            Err(err) => return Err(err),
        }
    }
    Ok(())
}

/// Receive first, then publish descriptors and message metadata as one transaction.
fn recv_message(
    fd: i32,
    msg: &mut msghdr,
    flags: u32,
    write_back: impl FnOnce(&msghdr, usize) -> KResult<()>,
) -> KResult<isize> {
    msg.msg_flags = 0;
    let mut namelen = msg.msg_namelen as socklen_t;
    let received = recv_impl(
        fd,
        IoVectorBuf::from_iovecs(IoVec::load_from_user(
            UserConstPtr::from(msg.msg_iov as usize),
            msg.msg_iovlen,
        )?)?
        .into_io(),
        flags,
        RecvOutput {
            addr: UserPtr::from(msg.msg_name as usize),
            addrlen: RecvAddrLen::Value(&mut namelen),
        },
    )?;
    msg.msg_namelen = namelen as _;
    msg.msg_flags = recv_truncate_to_msg_flag(received.flags);
    msg.msg_flags |= flags & MSG_CMSG_CLOEXEC;
    if flags & MSG_ERRQUEUE != 0 {
        msg.msg_flags |= MSG_ERRQUEUE;
    }
    if received.ancillary.is_empty() {
        msg.msg_controllen = 0;
        write_back(msg, received.len)?;
        return Ok(received.len as isize);
    }

    let resources = kprocess::current_resources();
    let table = resources.fd_table()?;
    let max_nofile = resources.max_nofile();
    let is_cloexec = flags & MSG_CMSG_CLOEXEC != 0;
    let mut installed = Vec::new();
    let mut rollback = Vec::new();
    let result = {
        // Only the copyout phase holds this lock, never the blocking receive.
        // Keep slot allocation and rollback indivisible so another thread cannot
        // replace an installed FD before a failed user copy is rolled back.
        // VM copyout resolves mappings without consulting the descriptor table.
        let mut table = table.write();
        let result = {
            let mut install_file = |file| {
                let fd = table.add_file(max_nofile, file, is_cloexec)?;
                installed.push(fd);
                Ok(fd)
            };
            // Retain the original references outside the lock, including
            // truncated rights whose last drop can enter a VFS release hook.
            receive_control_messages(msg, &received.ancillary, &mut install_file)
                .and_then(|()| write_back(msg, received.len))
        };
        if result.is_err() {
            for fd in installed {
                if let Ok(descriptor) = table.file_close_fd_locked(fd) {
                    rollback.push(descriptor);
                }
            }
        }
        result
    };
    // File close can enter VFS and must happen after releasing the table lock.
    for descriptor in rollback {
        let _ = descriptor.close();
    }
    result?;
    Ok(received.len as isize)
}

/// Receive data from a socket with the sender's address
pub fn sys_recvfrom(
    fd: i32,
    buf: *mut u8,
    len: usize,
    flags: u32,
    addr: UserPtr<sockaddr>,
    addrlen: UserPtr<socklen_t>,
) -> KResult<isize> {
    recv_impl(
        fd,
        VmBytesMut::new(buf, len),
        flags,
        RecvOutput::new(addr, addrlen),
    )
    .map(|received| received.len as isize)
}

/// Receive vectored data and ancillary messages into the current process.
///
/// Received rights become independent descriptors; `MSG_CMSG_CLOEXEC` sets
/// their close-on-exec bit. Insufficient control space sets `MSG_CTRUNC`.
/// Descriptors installed by this call are rolled back on control/metadata
/// copyout failure, after the socket has consumed the corresponding bytes.
pub fn sys_recvmsg(fd: i32, msg: UserPtr<msghdr>, flags: u32) -> KResult<isize> {
    let mut msg_value = msg.read_vm()?;
    recv_message(fd, &mut msg_value, flags, |value, _| {
        write_vm_mem(msg.as_ptr().cast_mut(), core::slice::from_ref(value))?;
        Ok(())
    })
}

fn recv_truncate_to_msg_flag(flags: RecvFlags) -> u32 {
    if flags.contains(RecvFlags::TRUNCATE) {
        MSG_TRUNC
    } else {
        0
    }
}

/// Send multiple datagrams in one syscall.
pub fn sys_sendmmsg(fd: i32, msgvec: UserPtr<mmsghdr>, vlen: u32, flags: u32) -> KResult<isize> {
    if vlen == 0 {
        return Ok(0);
    }
    if vlen > MMSG_MAX_VLEN {
        return Err(KError::InvalidInput);
    }

    let mut msgvec_value = msgvec.load_vm_vec(vlen as usize)?;
    let resources = kprocess::current_resources();
    let mut sent = 0;
    for msg in msgvec_value.iter_mut() {
        let ancillary = parse_send_cmsgs(
            resources.as_ref(),
            msg.msg_hdr.msg_control as usize,
            msg.msg_hdr.msg_controllen,
        )?;
        match send_impl(
            fd,
            IoVectorBuf::from_iovecs(IoVec::load_from_user(
                posix_types::UserConstPtr::from(msg.msg_hdr.msg_iov as usize),
                msg.msg_hdr.msg_iovlen,
            )?)?
            .into_io(),
            flags,
            UserConstPtr::from(msg.msg_hdr.msg_name as usize),
            msg.msg_hdr.msg_namelen as socklen_t,
            ancillary,
        ) {
            Ok(n) => {
                msg.msg_len = n as u32;
                sent += 1;
            }
            Err(e) => {
                if sent > 0 {
                    write_vm_mem(msgvec.as_ptr().cast_mut(), &msgvec_value)?;
                }
                if sent == 0 {
                    return Err(e);
                }
                break;
            }
        }
    }
    if sent > 0 {
        write_vm_mem(msgvec.as_ptr().cast_mut(), &msgvec_value)?;
    }
    Ok(sent)
}

/// Receive multiple datagrams in one syscall.
pub fn sys_recvmmsg(
    fd: i32,
    msgvec: UserPtr<mmsghdr>,
    vlen: u32,
    flags: u32,
    timeout: UserConstPtr<timespec>,
) -> KResult<isize> {
    if vlen == 0 {
        return Ok(0);
    }
    if vlen > MMSG_MAX_VLEN {
        return Err(KError::InvalidInput);
    }

    let timeout = parse_recvmmsg_timeout(timeout)?;
    // TODO: deadline is only checked between recv_impl calls. If a single
    // recv_impl blocks waiting for data (socket has nothing to read), the
    // deadline cannot interrupt it. Needs a non-blocking recv path or
    // SO_RCVTIMEO support at the socket layer to fix.
    let deadline = timeout.and_then(|span| monotonic_time().checked_add(span));

    let mut msgvec_value = msgvec.load_vm_vec(vlen as usize)?;
    let mut received = 0;
    for (index, msg) in msgvec_value.iter_mut().enumerate() {
        if let Some(deadline) = deadline
            && monotonic_time() >= deadline
        {
            if received == 0 {
                return Err(KError::WouldBlock);
            }
            break;
        }
        let output = (msgvec.as_ptr() as usize)
            .checked_add(index * size_of::<mmsghdr>())
            .ok_or(KError::InvalidInput)?;
        match recv_message(fd, &mut msg.msg_hdr, flags, |header, len| {
            let value = mmsghdr {
                msg_hdr: *header,
                msg_len: len as _,
            };
            write_vm_mem(output as *mut mmsghdr, core::slice::from_ref(&value))?;
            Ok(())
        }) {
            Ok(_) => received += 1,
            Err(err) => {
                if received == 0 {
                    return Err(err);
                }
                break;
            }
        }
    }
    Ok(received)
}
