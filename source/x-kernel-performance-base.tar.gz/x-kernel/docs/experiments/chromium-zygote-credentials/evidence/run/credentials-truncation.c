#define _GNU_SOURCE
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Linux ABI comparison for automatically generated Unix credentials.
 * No explicit SCM_CREDENTIALS are sent. Tests run independently of Chromium.
 */
static unsigned int failures;
static unsigned int cases;

static void fail(const char *label, const char *reason)
{
    fprintf(stderr, "FAIL %s: %s\n", label, reason);
    failures++;
}

static const char *kind_name(int kind)
{
    return kind == SOCK_DGRAM ? "dgram" : "seqpacket";
}

static void close_received_rights(struct msghdr *msg)
{
    /* Clean up even if a broken implementation returned unexpected rights. */
    for (struct cmsghdr *cmsg = CMSG_FIRSTHDR(msg); cmsg;
         cmsg = CMSG_NXTHDR(msg, cmsg)) {
        if (cmsg->cmsg_len < CMSG_LEN(0))
            break;
        if (cmsg->cmsg_level != SOL_SOCKET || cmsg->cmsg_type != SCM_RIGHTS)
            continue;
        size_t length = cmsg->cmsg_len - CMSG_LEN(0);
        for (size_t offset = 0; offset + sizeof(int) <= length;
             offset += sizeof(int)) {
            int fd;
            memcpy(&fd, (unsigned char *)CMSG_DATA(cmsg) + offset, sizeof(fd));
            close(fd);
        }
    }
}

static void run_case(int kind, size_t capacity, int send_rights)
{
    char label[100];
    snprintf(label, sizeof(label), "%s/%s/control=%zu", kind_name(kind),
             send_rights ? "rights+credentials" : "credentials", capacity);
    cases++;
    const unsigned int failures_before = failures;
    int pair[2] = {-1, -1};
    int passed_fd = -1;
    if (socketpair(AF_UNIX, kind, 0, pair) != 0) {
        perror(label);
        fail(label, "socketpair");
        return;
    }
    const int enabled = 1;
    if (setsockopt(pair[1], SOL_SOCKET, SO_PASSCRED, &enabled,
                   sizeof(enabled)) != 0) {
        fail(label, "setsockopt(SO_PASSCRED)");
        goto cleanup;
    }

    char sent = 'X';
    struct iovec send_iov = {.iov_base = &sent, .iov_len = 1};
    union {
        struct cmsghdr alignment;
        unsigned char bytes[CMSG_SPACE(sizeof(int))];
    } send_control = {0};
    struct msghdr send_msg = {.msg_iov = &send_iov, .msg_iovlen = 1};
    if (send_rights) {
        passed_fd = open("/dev/null", O_RDONLY);
        if (passed_fd < 0) {
            fail(label, "open(/dev/null)");
            goto cleanup;
        }
        send_msg.msg_control = send_control.bytes;
        send_msg.msg_controllen = sizeof(send_control.bytes);
        struct cmsghdr *cmsg = CMSG_FIRSTHDR(&send_msg);
        cmsg->cmsg_level = SOL_SOCKET;
        cmsg->cmsg_type = SCM_RIGHTS;
        cmsg->cmsg_len = CMSG_LEN(sizeof(passed_fd));
        memcpy(CMSG_DATA(cmsg), &passed_fd, sizeof(passed_fd));
    }
    if (sendmsg(pair[0], &send_msg, 0) != 1) {
        fail(label, "sendmsg");
        goto cleanup;
    }

    union {
        struct cmsghdr alignment;
        unsigned char bytes[128];
    } recv_control;
    memset(&recv_control, 0xa5, sizeof(recv_control));
    char received = 0;
    struct iovec recv_iov = {.iov_base = &received, .iov_len = 1};
    struct msghdr recv_msg = {
        .msg_iov = &recv_iov,
        .msg_iovlen = 1,
        .msg_control = recv_control.bytes,
        .msg_controllen = capacity,
    };
    if (recvmsg(pair[1], &recv_msg, MSG_DONTWAIT) != 1 || received != sent) {
        fail(label, "recvmsg must preserve the data byte");
        goto cleanup;
    }
    close_received_rights(&recv_msg);

    const struct ucred expected = {
        .pid = getpid(), .uid = getuid(), .gid = getgid(),
    };
    const size_t header_size = CMSG_LEN(0);
    const size_t complete_length = CMSG_LEN(sizeof(expected));
    const size_t complete_space = CMSG_SPACE(sizeof(expected));
    const int expect_truncation = send_rights || capacity < complete_length;
    const size_t expected_used = capacity < header_size ? 0 :
        (capacity < complete_space ? capacity : complete_space);
    struct cmsghdr *first = CMSG_FIRSTHDR(&recv_msg);

    printf("OBS %s returned_control=%zu flags=0x%x first_type=%d first_len=%zu\n",
           label, (size_t)recv_msg.msg_controllen, recv_msg.msg_flags,
           first ? first->cmsg_type : -1, first ? (size_t)first->cmsg_len : 0);
    if (!!(recv_msg.msg_flags & MSG_CTRUNC) != expect_truncation)
        fail(label, "MSG_CTRUNC does not match the available control space");
    if (recv_msg.msg_flags & ~MSG_CTRUNC)
        fail(label, "unexpected receive flags");
    if (recv_msg.msg_controllen != expected_used)
        fail(label, "msg_controllen differs from Linux's consumed-space ABI");
    if (capacity < header_size) {
        if (first)
            fail(label, "incomplete header must not be published");
    } else if (!first) {
        fail(label, "missing credentials header");
    } else {
        const size_t body_capacity = capacity - header_size;
        const size_t body_length = body_capacity < sizeof(expected) ?
            body_capacity : sizeof(expected);
        if (first->cmsg_level != SOL_SOCKET ||
            first->cmsg_type != SCM_CREDENTIALS)
            fail(label, "credentials must precede rights");
        if (first->cmsg_len != CMSG_LEN(body_length))
            fail(label, "partial credential header reports the wrong length");
        if (memcmp(CMSG_DATA(first), &expected, body_length) != 0)
            fail(label, "credential body/prefix differs from the actual sender");
        if (CMSG_NXTHDR(&recv_msg, first))
            fail(label, "unexpected second control message");
    }
    if (failures == failures_before)
        printf("PASS %s\n", label);

cleanup:
    if (passed_fd >= 0)
        close(passed_fd);
    close(pair[0]);
    close(pair[1]);
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    const size_t header_size = CMSG_LEN(0);
    const size_t capacities[] = {
        0, header_size - 1, header_size, header_size + 1,
        header_size + 4, header_size + 8, header_size + 11,
        CMSG_LEN(sizeof(struct ucred)),
        CMSG_SPACE(sizeof(struct ucred)) - 1,
        CMSG_SPACE(sizeof(struct ucred)),
    };
    printf("ABI cmsghdr=%zu ucred=%zu cmsg_len=%zu cmsg_space=%zu\n",
           sizeof(struct cmsghdr), sizeof(struct ucred),
           CMSG_LEN(sizeof(struct ucred)), CMSG_SPACE(sizeof(struct ucred)));
    for (size_t kind_index = 0; kind_index < 2; kind_index++) {
        const int kind = kind_index == 0 ? SOCK_DGRAM : SOCK_SEQPACKET;
        run_case(kind, CMSG_SPACE(sizeof(struct ucred)), 1);
        for (size_t i = 0; i < sizeof(capacities) / sizeof(capacities[0]); i++)
            run_case(kind, capacities[i], 0);
    }
    printf("SUMMARY cases=%u failures=%u\n", cases, failures);
    return failures ? EXIT_FAILURE : EXIT_SUCCESS;
}
