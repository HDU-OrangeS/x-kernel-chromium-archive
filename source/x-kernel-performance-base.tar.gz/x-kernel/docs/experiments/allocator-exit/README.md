# 驻留匿名页释放与进程退出探针

`resident-exit-probe.c` 用于区分大量已触页内存的释放开销与稀疏虚拟地址空间遍历开销。它是用户空间行为与性能实验，不是内核内部结构单元测试，也没有“必须在某个毫秒数内完成”的性能断言。

本机没有完整的 Starry Test Harness checkout；本目录未注册或宣称执行其 suite。本次使用已有编译器生成独立程序，主机 Linux 先作契约对照，再将同一个静态 AArch64 二进制交给客体实验。没有下载或安装工具。

## 行为契约

每次执行只创建一个直接子进程。子进程映射连续的 8、32 或 64 MiB 匿名私有可读写范围，并在其前后各放一页已写入标记的保护数据页。保护数据页仍然可读写，用于发现越界释放，不是 `PROT_NONE` 防护页。

准备阶段完成以下工作后才发送开始记录：

1. 对目标范围的每一页、每一个字节写入与页索引有关的非零标记。
2. 逐页重新读取所有字节，校验标记；记录 `touched_pages` 和 `verified_pages`。
3. 默认不调用 `mincore`，记录 `mincore_attempted=false`、`mincore_available=false`、`resident_pages=null`。仅显式传入 `--mincore` 时尝试读取当时的驻留页数；调用失败时记录 `mincore_errno`，基本契约不因此失败。当前 X-Kernel 的该可选路径存在已定位的锁重入，应在 Linux 对照中使用。
4. 校验两侧保护数据页。

模式及释放顺序：

| 模式 | 操作 | 返回成功的必要条件 |
| --- | --- | --- |
| `exit` | 子进程保留完整映射，调用 `_exit(0)`；父进程有界等待回收 | 所有目标页均写入并校验，准备成功，父进程收回正常退出的直接子进程 |
| `sequential` | 按虚拟页索引 `0,1,2,…,N-1`，每页调用一次 `munmap` | 每次解除映射成功，调用次数为 N，两侧数据保持，重新映射原范围后所有字节为零 |
| `even-odd` | 先解除 `0,2,4,…`，再解除 `1,3,5,…`，同样共 N 次 `munmap` | 与 `sequential` 相同 |

两种显式释放模式在完成计时后，用 `MAP_FIXED` 重新映射**自己刚刚解除的目标范围**，读遍所有字节验证匿名页为零，再解除该范围并退出。这部分校验耗时不包含在 `elapsed_seconds` 中，但包含在 `wait_elapsed_seconds` 中。失败时子进程退出，由内核回收剩余映射；不会覆盖其他进程地址空间。

本探针没有使用 `MADV_DONTNEED`，避免把其支持程度混入当前退出问题。

## 计时和解释边界

- `elapsed_seconds`：`exit` 是发送准备完成记录前的时间戳至父进程观察到子进程回收；包含管道、调度和最多约 1 ms 的父进程轮询间隔，不能解释为纯内核清理耗时。显式释放模式是准备完成至最后一次逐页 `munmap` 返回，包含循环和系统调用成本。
- `wait_elapsed_seconds`：准备完成至父进程观察到子进程退出，显式释放模式还包括重新映射与零初始化检查。
- 8、32、64 MiB 在 4 KiB 页面配置下分别是 2048、8192、16384 个目标逻辑页；另有 2 个保护数据页和程序自身的栈、代码等。`exit` 释放整个子进程，因此不仅释放目标范围。
- 全页写入并读取证明目标页已实际可访问；只有显式选择且 `mincore` 成功才提供一个时点上的驻留计数。默认 `resident_pages=null` 表示未测，不能解释为零个驻留页。不能仅凭该计数断言目标内核没有共享零页、交换或大页。
- **相邻虚拟页不保证是物理 buddy 配对**。偶奇释放仅在虚拟顺序上把相邻页分开，不能作为真实物理碎片模型或 allocator 锁的独立证明。
- `even-odd` 还会产生更多 VMA 拆分和查找。两种显式释放模式虽然系统调用次数相同，时间差也不能全部归因于物理页分配器。
- 不关闭宿主 THP、不给工作负载绑核、不修改全局 sysctl。主机与 QEMU 测量不能直接作为同硬件性能比率。
- `remap_zero_ok=false` 在 `exit` 模式表示**未执行该项检查**；不是失败。

## 构建

在仓库根目录执行：

```bash
mkdir -p target/experiments/allocator-exit-20261009
cc -O2 -std=c11 -Wall -Wextra -Werror \
  docs/experiments/allocator-exit/resident-exit-probe.c \
  -o target/experiments/allocator-exit-20261009/resident-exit-probe-linux
/home/cuizh/toolchains/aarch64-linux-musl-cross/bin/aarch64-linux-musl-gcc \
  -static -O2 -std=c11 -Wall -Wextra -Werror \
  docs/experiments/allocator-exit/resident-exit-probe.c \
  -o target/experiments/allocator-exit-20261009/resident-exit-probe-aarch64
```

`cc` 构建当前 Linux 主机程序；交叉编译器构建静态 AArch64 程序。`-O2` 启用优化，`-std=c11` 使用 C11，三个警告选项要求编译警告视为错误。工具链的静态产物为 static PIE。

## 执行与有界清理

程序格式：

```text
resident-exit-probe exit|sequential|even-odd 8|32|64 [timeout_seconds [--mincore]]
```

超时默认 120 秒，可指定 1–300 秒。准备阶段（包含全页写入和校验）和执行/回收阶段各有一个该时长的 deadline；超时后最多再等 2 秒回收。超时是实验防护，会输出失败状态，不是性能合格阈值。

父进程收到 `SIGINT`/`SIGTERM` 或超时后，只对仍未回收的**自己直接 fork 的子进程 PID**发 `SIGKILL`，不会发送到进程组。若内核清理阻塞导致无法回收，最多等待 2 秒并输出 `reaped=false`，交给外部实验控制器处置所属 VM；不假装完成清理。父进程被不可捕获的 `SIGKILL` 终止时无法执行此清理，因此外部控制器应先给予 `SIGTERM` 和清理宽限期。

客体先只运行退出模式，逐个收集输出：

```bash
/root/resident-exit-probe exit 8 120
/root/resident-exit-probe exit 32 120
/root/resident-exit-probe exit 64 120
```

三条命令分别测试 8、32、64 MiB 全触页后的子进程退出。输出为一行 JSON，须同时检查进程退出码与 `passed`、`reaped`、`forced_cleanup`。

需要分析顺序差异时，再单独执行 8 MiB 显式释放对照：

```bash
/root/resident-exit-probe sequential 8 120
/root/resident-exit-probe even-odd 8 120
```

逐页解除映射的 32/64 MiB 客体用例不默认批量执行：这会产生最多 16384 次系统调用和大量 VMA 拆分，可能耗时数分钟，应根据较小用例证据再决定。

## 2026-10-09 主机对照

原始记录位于 `target/experiments/allocator-exit-20261009/`：

- `linux-{exit,sequential,even-odd}-{8,32,64}.json`：v2 的 9 项独立默认结果，全部通过，所有目标页均写入/校验，均未执行 `mincore`。
- `linux-summary.json`：平台、主机二进制哈希及 9 项摘要。
- `linux-mincore-opt-in.json`：仅 Linux 额外执行 `exit 8 10 --mincore`，返回 2048 个驻留页，与已写入/校验的 2048 页相符；不计入 9 项默认用例。
- `linux-cleanup-parent-interrupt.json`：外部控制器仅暂停已确认的探针直接子进程，再向探针父进程发送 `SIGTERM`；程序以失败码退出，`interrupted=true`、`forced_cleanup=true`、`reaped=true`，清理控制检查通过。
- `linux-cleanup-preparation-timeout.json`：同样只暂停探针自己的子进程，等待 1 秒配置的 deadline；程序报告失败并只清理该子进程，最终回收，清理控制检查通过。

这两项受控失败是对清理边界的验证，**不计入 9 项正常成功数**。客体结果与真实 Chromium 前后对照见 [阶段验证结果](RESULTS-20261009.md)。本段只统计 Linux 对照，不能与客体通过数混用。

v2 源码 SHA256：`433654392c099823065b330661df30bf19bb0786362c7073efff8842e92f989b`。

v2 静态 AArch64 二进制 SHA256：`4603a8c4b4eb976f9e64f04cbfb89b5b54205f4d6368bcdd68402b0c7926733d`。

## v1 客体失败与诊断边界

v1 默认附带 `mincore` 观察，Linux 9 项通过，但在首个客体 `exit 8` 用例中触发内核 panic，不能记为客体通过或退出释放失败。完整 v1 源码、README、二进制、主机结果及哈希已冻结在 `target/experiments/allocator-exit-20261009/probe-v1-mincore-default/`；原始 guest `probe-before/serial.log` 和符号化 `panic-symbols.log` 由主实验保留。

符号化显示链路为：

```text
posix_mm::mincore::sys_mincore (mincore.rs:125)
  → UserPtr::write_vm_slice
  → kuaccess::copy_user_pages
  → LiveAddressSpace::lock
  → RawMutex 检测到同任务重复持有 mm 锁
```

这说明可选驻留观测走到持有 mm 锁后再经用户内存复制例程获取同一个锁的路径；不能简单断言由“用户栈缺页”引起。v2 将该观测改为显式选择，使默认实验专注全触页后的退出/释放，不修补内核 `mincore`，也不宣称这个独立故障已经解决。默认路径仍保留完整逐页写入和校验。
