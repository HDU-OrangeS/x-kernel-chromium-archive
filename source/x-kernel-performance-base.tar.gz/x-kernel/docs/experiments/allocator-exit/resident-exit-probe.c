/* SPDX-License-Identifier: Apache-2.0 */
/* Fully populated anonymous mappings: observable release and exit probe. */
#define _GNU_SOURCE
#include <errno.h>
#include <poll.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

enum { START = 1, DONE = 2, SETUP_ERROR = 3 };
enum mode { EXIT, SEQUENTIAL, EVEN_ODD };
struct record {
    int kind, error, mincore_attempted, mincore_error, guards_ok, remap_zero_ok;
    size_t page_bytes, touched_pages, verified_pages, resident_pages, unmap_calls;
    double time;
};
static volatile sig_atomic_t interrupted;

static void interrupt_handler(int number)
{
    (void)number;
    interrupted = 1;
}

static double now(void)
{
    struct timespec value;
    if (clock_gettime(CLOCK_MONOTONIC, &value)) _exit(125);
    return value.tv_sec + value.tv_nsec / 1000000000.0;
}

static void report(int fd, const struct record *record)
{
    ssize_t count;
    do { count = write(fd, record, sizeof(*record)); } while (count < 0 && errno == EINTR);
    if (count != (ssize_t)sizeof(*record)) _exit(126);
}

static unsigned char pattern(size_t page)
{
    return (unsigned char)(1 + page % 251);
}

static int bytes_are(const unsigned char *address, size_t bytes, unsigned char value)
{
    for (size_t offset = 0; offset < bytes; ++offset)
        if (address[offset] != value) return 0;
    return 1;
}

static void run_child(int fd, size_t bytes, enum mode mode, int use_mincore)
{
    struct record record = {.kind = SETUP_ERROR};
    long page_value = sysconf(_SC_PAGESIZE);
    if (page_value <= 0 || bytes % (size_t)page_value ||
        bytes > SIZE_MAX - 2 * (size_t)page_value) {
        record.error = EINVAL;
        goto setup_error;
    }
    const size_t page = (size_t)page_value;
    const size_t pages = bytes / page;
    /* Sized for the allowed 64 MiB maximum and minimum 4 KiB system page.
     * The optional mincore observation requires explicit opt-in: some guest
     * kernels panic in its user-copy path rather than returning an error. */
    unsigned char resident[16384];
    unsigned char *mapping = mmap(NULL, bytes + 2 * page, PROT_READ | PROT_WRITE,
                                 MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (mapping == MAP_FAILED) {
        record.error = errno;
        goto setup_error;
    }
    unsigned char *range = mapping + page;
    unsigned char *upper_guard = range + bytes;
    record.page_bytes = page;
    memset(mapping, 0xa5, page);
    memset(upper_guard, 0x5a, page);
    for (size_t index = 0; index < pages; ++index) {
        memset(range + index * page, pattern(index), page);
        record.touched_pages++;
    }
    for (size_t index = 0; index < pages; ++index) {
        if (!bytes_are(range + index * page, page, pattern(index))) {
            record.error = EIO;
            goto setup_error;
        }
        record.verified_pages++;
    }
    if (use_mincore) {
        if (pages > sizeof(resident)) {
            record.mincore_error = EOVERFLOW;
        } else {
            record.mincore_attempted = 1;
            if (mincore(range, bytes, resident)) {
                record.mincore_error = errno;
            } else {
                for (size_t index = 0; index < pages; ++index)
                    record.resident_pages += !!(resident[index] & 1);
            }
        }
    }
    record.guards_ok = bytes_are(mapping, page, 0xa5) && bytes_are(upper_guard, page, 0x5a);
    if (!record.guards_ok) {
        record.error = EIO;
        goto setup_error;
    }
    record.kind = START;
    record.time = now();
    report(fd, &record);
    if (mode == EXIT) _exit(0);

    /* Both release orders issue exactly one munmap per logical page.
     * This does not claim virtual neighbours are physical buddy pairs. */
    for (size_t step = 0; step < pages; ++step) {
        const size_t index = mode == SEQUENTIAL ? step :
            (step < (pages + 1) / 2 ? 2 * step : 2 * (step - (pages + 1) / 2) + 1);
        if (munmap(range + index * page, page)) {
            record.error = errno;
            record.kind = DONE;
            record.time = now();
            report(fd, &record);
            _exit(2);
        }
        record.unmap_calls++;
    }
    /* Save the end before post-release verification and remapping. */
    record.time = now();
    record.guards_ok = bytes_are(mapping, page, 0xa5) && bytes_are(upper_guard, page, 0x5a);
    /* Only replace the range this child owned and has just unmapped. */
    void *replacement = mmap(range, bytes, PROT_READ | PROT_WRITE,
                             MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    if (replacement == MAP_FAILED) {
        record.error = errno;
    } else {
        record.remap_zero_ok = replacement == range && bytes_are(range, bytes, 0);
        if (munmap(range, bytes)) record.error = errno;
    }
    record.guards_ok = record.guards_ok && bytes_are(mapping, page, 0xa5) &&
                       bytes_are(upper_guard, page, 0x5a);
    record.kind = DONE;
    report(fd, &record);
    _exit(!record.error && record.guards_ok && record.remap_zero_ok ? 0 : 1);

setup_error:
    record.time = now();
    report(fd, &record);
    _exit(2);
}

static int read_record(int fd, struct record *record, double deadline)
{
    size_t offset = 0;
    while (offset < sizeof(*record) && !interrupted) {
        double remaining = deadline - now();
        if (remaining <= 0) return 0;
        struct pollfd item = {fd, POLLIN, 0};
        int result = poll(&item, 1, (int)(remaining * 1000) + 1);
        if (result < 0 && errno == EINTR) continue;
        if (result <= 0) return 0;
        ssize_t count = read(fd, (char *)record + offset, sizeof(*record) - offset);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) return 0;
        offset += (size_t)count;
    }
    return offset == sizeof(*record);
}

static int wait_child(pid_t child, int *status, double deadline, int is_cleanup)
{
    do {
        pid_t result = waitpid(child, status, WNOHANG);
        if (result == child) return 1;
        if (result < 0 && errno != EINTR) return -1;
        if (interrupted && !is_cleanup) return 0;
        struct timespec delay = {0, 1000000};
        (void)nanosleep(&delay, NULL);
    } while (now() < deadline);
    return 0;
}

int main(int argc, char **argv)
{
    const char *mode_name = argc >= 2 ? argv[1] : "exit";
    enum mode mode;
    if (!strcmp(mode_name, "exit")) mode = EXIT;
    else if (!strcmp(mode_name, "sequential")) mode = SEQUENTIAL;
    else if (!strcmp(mode_name, "even-odd")) mode = EVEN_ODD;
    else goto usage;
    char *end = NULL;
    unsigned long mib = argc >= 3 ? strtoul(argv[2], &end, 10) : 8;
    int use_mincore = argc == 5 && !strcmp(argv[4], "--mincore");
    if (argc > 5 || (argc == 5 && !use_mincore) ||
        (argc >= 3 && (!*argv[2] || *end)) ||
        !(mib == 8 || mib == 32 || mib == 64)) goto usage;
    double timeout = argc >= 4 ? strtod(argv[3], &end) : 120;
    if (!(timeout >= 1 && timeout <= 300) ||
        (argc >= 4 && (!*argv[3] || *end))) goto usage;
    struct sigaction action = {.sa_handler = interrupt_handler};
    sigemptyset(&action.sa_mask);
    if (sigaction(SIGINT, &action, NULL) || sigaction(SIGTERM, &action, NULL)) {
        perror("sigaction");
        return 2;
    }
    int pipefd[2];
    if (pipe(pipefd)) { perror("pipe"); return 2; }
    pid_t child = fork();
    if (child < 0) { perror("fork"); close(pipefd[0]); close(pipefd[1]); return 2; }
    if (!child) {
        signal(SIGINT, SIG_DFL);
        signal(SIGTERM, SIG_DFL);
        close(pipefd[0]);
        run_child(pipefd[1], (size_t)mib * 1024 * 1024, mode, use_mincore);
    }
    close(pipefd[1]);
    struct record start = {0}, done = {0};
    int started = read_record(pipefd[0], &start, now() + timeout) && start.kind == START;
    double deadline = now() + timeout;
    int got_done = mode == EXIT || (started && read_record(pipefd[0], &done, deadline));
    int status = 0;
    int reaped = wait_child(child, &status, deadline, 0);
    double finished = now();
    int forced_cleanup = 0;
    int passed = started && got_done && reaped == 1 && !interrupted &&
                 WIFEXITED(status) && WEXITSTATUS(status) == 0 && !start.error &&
                 start.guards_ok && start.touched_pages == start.verified_pages &&
                 start.page_bytes * start.verified_pages == mib * 1024 * 1024;
    if (mode != EXIT)
        passed = passed && done.kind == DONE && !done.error && done.guards_ok &&
                 done.remap_zero_ok && done.unmap_calls == start.verified_pages;
    if (reaped == 0) {
        /* An unreaped direct child cannot have its PID reused. Never signal a
         * process group or unrelated PID, including on timeout/interruption. */
        forced_cleanup = 1;
        (void)kill(child, SIGKILL);
        reaped = wait_child(child, &status, now() + 2, 1);
    }
    close(pipefd[0]);
    const double elapsed = started ?
        (mode != EXIT && got_done && done.kind == DONE ? done.time : finished) - start.time : -1;
    const int mincore_available = started && start.mincore_attempted && !start.mincore_error;
    char resident_json[32];
    if (mincore_available) snprintf(resident_json, sizeof(resident_json), "%zu", start.resident_pages);
    else snprintf(resident_json, sizeof(resident_json), "null");
    printf("{\"mode\":\"%s\",\"mib\":%lu,\"child_pid\":%ld,\"page_bytes\":%zu,"
           "\"logical_pages\":%zu,\"touched_pages\":%zu,\"verified_pages\":%zu,"
           "\"mincore_attempted\":%s,\"mincore_available\":%s,\"mincore_errno\":%d,\"resident_pages\":%s,"
           "\"guard_pages\":2,\"unmap_calls\":%zu,\"started\":%s,\"passed\":%s,"
           "\"elapsed_seconds\":%.9f,\"wait_elapsed_seconds\":%.9f,"
           "\"phase_timeout_seconds\":%.3f,\"wait_status\":%d,\"reaped\":%s,"
           "\"forced_cleanup\":%s,\"interrupted\":%s,\"setup_errno\":%d,"
           "\"release_errno\":%d,\"guards_ok\":%s,\"remap_zero_ok\":%s}\n",
           mode_name, mib, (long)child, start.page_bytes, start.page_bytes ?
           (size_t)mib * 1024 * 1024 / start.page_bytes : 0,
           start.touched_pages, start.verified_pages,
           start.mincore_attempted ? "true" : "false",
           mincore_available ? "true" : "false", start.mincore_error,
           resident_json, done.unmap_calls, started ? "true" : "false",
           passed ? "true" : "false", elapsed, started ? finished - start.time : -1,
           timeout, status, reaped == 1 ? "true" : "false",
           forced_cleanup ? "true" : "false", interrupted ? "true" : "false",
           start.kind == SETUP_ERROR ? start.error : 0, done.error,
           (mode == EXIT ? start.guards_ok : done.guards_ok) ? "true" : "false",
           done.remap_zero_ok ? "true" : "false");
    return passed ? 0 : 1;

usage:
    fprintf(stderr, "usage: %s [exit|sequential|even-odd [8|32|64 [timeout_seconds=120 [--mincore]]]]\n", argv[0]);
    return 2;
}
