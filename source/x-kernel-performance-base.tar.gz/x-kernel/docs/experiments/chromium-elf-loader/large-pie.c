#include <stdint.h>
#include <stdio.h>
#include <sys/auxv.h>
static volatile unsigned char image_data[80 * 1024 * 1024];
int main(void) {
    uintptr_t base=getauxval(AT_BASE);
    uintptr_t begin=(uintptr_t)&image_data[0], end=begin+sizeof(image_data);
    printf("large PIE: BSS=[%#lx,%#lx), AT_BASE=%#lx\n",(unsigned long)begin,(unsigned long)end,(unsigned long)base);
    if(!base || (base >= begin && base < end)) return 1;
    if(image_data[0] || image_data[sizeof(image_data)-1]) return 2;
    image_data[0]=17; image_data[sizeof(image_data)-1]=91;
    if(image_data[0]!=17 || image_data[sizeof(image_data)-1]!=91) return 3;
    puts("PASS: large dynamic PIE reached main; relocated interpreter and zero-filled BSS work");
    return 0;
}
