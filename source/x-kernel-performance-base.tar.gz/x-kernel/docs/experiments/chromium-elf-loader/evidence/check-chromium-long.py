from pathlib import Path
import os, json, socket, time, pexpect
root=Path('/tmp/xkernel-chromium-elf')
qmp_path=str(root/'weston-qmp.sock')
args=['-m','2g','-smp','4','-cpu','cortex-a76','-machine','virt,gic-version=3',
 '-kernel',str(root/'kernel-fixed.bin'),
 '-device','virtio-blk-pci,drive=disk0','-drive','id=disk0,if=none,format=raw,file=/home/cuizh/x-kernel/disk.img',
 '-snapshot','-object','rng-random,id=host_rng0','-device','virtio-rng-pci,rng=host_rng0','-device','virtio-gpu-pci','-vga','none','-display','none','-serial','stdio','-monitor','none',
 '-qmp',f'unix:{qmp_path},server=on,wait=off','-device','virtio-keyboard-pci','-device','virtio-tablet-pci']
env=dict(os.environ)
for key in ['GTK_PATH','GIO_MODULE_DIR']: env.pop(key,None)
(root/'weston-qemu-args.json').write_text(json.dumps(args,indent=2))
log=(root/'chromium-long-guest.log').open('w')
child=pexpect.spawn('qemu-system-aarch64',args,env=env,encoding='utf-8',timeout=45,maxread=65536)
child.logfile=log
qmp=None
try:
 child.expect('kylin-x:~# ')
 def run(cmd):
  child.sendline(cmd+(' ' if cmd.rstrip().endswith('&') else '; ')+'printf "\\n__CHECK_DONE:%s__\\n" "$?"')
  child.expect(r'\r\n__CHECK_DONE:(\d+)__')
  rc=int(child.match.group(1)); output=child.before
  child.expect('kylin-x:~# ')
  if rc: raise RuntimeError(f'guest command failed ({rc}): {cmd}\n{output}')
  return output
 run('ps; cat /sys/class/drm/card0/dev; cat /sys/class/drm/card0/uevent')
 run('command -v weston; command -v seatd; command -v weston-simple-shm')
 run('export XDG_RUNTIME_DIR=/run/user/0; mkdir -p "$XDG_RUNTIME_DIR"; chmod 700 "$XDG_RUNTIME_DIR"')
 run('SEATD_VTBOUND=0 seatd -g root -l debug > /tmp/seatd-permanent.log 2>&1 &')
 run('sleep 1; pidof seatd')
 run('LIBSEAT_BACKEND=seatd SEATD_SOCK=/run/seatd.sock weston --backend=drm --renderer=pixman --drm-device=card0 --continue-without-input --idle-time=0 --log=/tmp/weston-permanent.log > /tmp/weston-permanent-stderr.log 2>&1 &')
 run('sleep 4; cat /tmp/weston-permanent.log; cat /tmp/weston-permanent-stderr.log; pidof weston')
 run('for sock in "$XDG_RUNTIME_DIR"/wayland-*; do if [ -S "$sock" ]; then export WAYLAND_DISPLAY="${sock##*/}"; break; fi; done; test -n "$WAYLAND_DISPLAY"; echo "$WAYLAND_DISPLAY"')
 run('chromium --ozone-platform=wayland --no-sandbox --disable-gpu --user-data-dir=/tmp/chromium-wayland-test --no-first-run --enable-logging=stderr about:blank > /tmp/chromium-test.log 2>&1 &')
 run('sleep 20; cat /tmp/chromium-test.log; ps')
 qmp=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM); qmp.settimeout(5); qmp.connect(qmp_path)
 stream=qmp.makefile('rwb',buffering=0)
 def receive():
  while True:
   response=json.loads(stream.readline())
   if 'return' in response: return response['return']
   if 'error' in response: raise RuntimeError(response)
 stream.readline()
 def execute(command,arguments=None):
  message={'execute':command}
  if arguments: message['arguments']=arguments
  stream.write((json.dumps(message)+'\n').encode()); return receive()
 execute('qmp_capabilities')
 execute('screendump',{'filename':str(root/'chromium-long-1.ppm')})
 
 for iteration in range(4):
  run('sleep 25; tail -n 50 /tmp/chromium-test.log; ps')
 run('cat /tmp/weston-permanent.log; cat /tmp/seatd-permanent.log')
 execute('screendump',{'filename':str(root/'chromium-long-2.ppm')})
 print('Chromium attempt completed; inspect serial log and screenshots for outcome.')
finally:
 if qmp: qmp.close()
 child.terminate(force=True)
 log.close()
