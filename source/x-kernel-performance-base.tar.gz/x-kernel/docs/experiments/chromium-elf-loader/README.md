# 2026-10-03：Chromium 启动时 ELF 装载地址冲突修复

## 结论与验收边界

这次 `VmAreaSet::insert` panic 的根因是：装载器把动态链接器固定放在虚拟地址
`0x04000000`（64 MiB），而 Chromium 主程序的加载段已经覆盖了该地址。
修复已落到本地代码，并通过复现前后对比及相关单元测试。

**这份报告证明 ELF 装载冲突已修复，不代表 Chromium 窗口、网页渲染或输入已经通过。**
实际浏览器已进入 Wayland/GTK 初始化，后续观察结果见文末。

本次没有修改工作 `disk.img`、没有下载依赖、没有提交或推送 Git。QEMU 图形验证使用
快照，所有客体写入进入临时覆盖层。已有 SCM_RIGHTS、DRM sysfs 工作保留；
用户原有的 `xtask/Cargo.lock` 改动没有归入本次补丁。

## 整个故障链

```mermaid
flowchart TD
    A[guest shell 执行 chromium] --> B[execve 加载实际 Chromium ELF]
    B --> C[加载主程序 PT_LOAD 段]
    C --> D[加载 PT_INTERP 指定的 musl 动态链接器]
    D --> E[旧逻辑固定 load bias 为 64 MiB]
    E --> F[落在 Chromium 已占用的 VMA 内]
    F --> G[惰性映射尚未建立 PTE，未在前段拒绝冲突]
    G --> H[VmAreaSet insert 内部断言失败]
    H --> I[内核 panic，QEMU 退出]
    I --> J[回到 Ubuntu shell，客体 tmp 日志不可从宿主同名路径读取]
```

这条调用链与用户符号化回溯一致：
`sys_execve → commit_prepared_binprm → map_elf → map_runtime_vma → VmAreaSet::insert`。
它发生在执行文件装载阶段，比 Chromium 的 Wayland 绘图更早。
增加 QEMU 的物理内存不能消除两个映射使用同一虚拟地址的冲突。

## 直接证据

通过 `debugfs` 只读提取工作镜像中的真实 ELF，用 `readelf -lW` 检查，未依赖猜测的浏览器大小。
真实程序为 `/usr/lib/chromium/chromium`，ELF 类型 ET_DYN，解释器为
`/lib/ld-musl-aarch64.so.1`。对应原始输出位于 `evidence/*.readelf.txt`。

Chromium 的可执行 PT_LOAD 段：

| 项目 | 数值 |
|---|---|
| ELF 中的虚拟地址 | `0x01a2e000` |
| 段内存大小 | `0x0b9afb80` |
| 当前主程序 load bias | `0x1000` |
| 页对齐后的占用区间 | `[0x01a2f000, 0x0d3df000)` |
| 旧解释器 load bias | `0x04000000`，位于上述区间内 |

musl 解释器的最大 PT_LOAD 末端为 `0xc3310`，最大对齐为 `0x10000`；
本修复为它寻找至少 `0xd0000` 大小、64 KiB 对齐的空闲跨度。
这是虚拟地址布局；不是浏览器实际一次性消耗了这些物理内存。

## 修复代码与位置

### 1. 装载器选择不冲突的解释器地址

位置：[loader.rs](/home/cuizh/x-kernel/process/kexec/src/loader.rs:285)。
调用点：[commit_prepared_binprm](/home/cuizh/x-kernel/process/kexec/src/loader.rs:498)。

旧代码对解释器直接调用：

```rust
map_elf(uspace, kaddr_layout::USER_INTERP_BASE, elf)
```

新代码对 ET_DYN 解释器计算跨度、检查溢出与对齐，再查找空闲区域。
原来 64 MiB 的地址只作为优先尝试的提示；如果被占用就选择其他地址。
ET_EXEC 解释器继续使用它的链接地址。完整选址函数：

```rust
fn find_interpreter_bias(
    uspace: &MmSpace,
    headers: &[xmas_elf::program::ProgramHeader64],
) -> KResult<usize> {
    let mut image_end = 0usize;
    let mut alignment = PAGE_SIZE_4K;
    for ph in headers
        .iter()
        .filter(|ph| ph.get_type() == Ok(xmas_elf::program::Type::Load) && ph.mem_size != 0)
    {
        let start = usize::try_from(ph.virtual_addr).map_err(|_| KError::InvalidExecutable)?;
        let size = usize::try_from(ph.mem_size).map_err(|_| KError::InvalidExecutable)?;
        let end = start.checked_add(size).ok_or(KError::InvalidExecutable)?;
        let segment_alignment = usize::try_from(ph.align).map_err(|_| KError::InvalidExecutable)?;
        if segment_alignment > 1 && !segment_alignment.is_power_of_two() {
            return Err(KError::InvalidExecutable);
        }
        alignment = alignment.max(segment_alignment);
        image_end = image_end.max(end);
    }
    if image_end == 0 {
        return Err(KError::InvalidExecutable);
    }
    let span = image_end
        .checked_add(alignment - 1)
        .ok_or(KError::InvalidExecutable)?
        & !(alignment - 1);
    let limit_end = uspace
        .end()
        .min(VirtAddr::from_usize(kaddr_layout::USER_HEAP_BASE));
    if limit_end <= uspace.base() || span > limit_end.as_usize() - uspace.base().as_usize() {
        return Err(KError::NoMemory);
    }
    let limit = VirtAddrRange::new(uspace.base(), limit_end);
    let find = |hint| {
        uspace
            .find_free_area(hint, span, limit, alignment)
            .filter(|start| {
                start
                    .as_usize()
                    .checked_add(span)
                    .is_some_and(|end| end <= limit.end.as_usize())
            })
    };
    find(VirtAddr::from_usize(kaddr_layout::USER_INTERP_BASE))
        .or_else(|| find(limit.start))
        .map(|start| start.as_usize())
        .ok_or(KError::NoMemory)
}

```

选址包含段间空洞，但只检查并选择跨度，不会额外映射这些空洞。
已有 `find_free_area` 在遍历后续 VMA 时可能返回超出 limit 的候选，因此调用端再次
检查候选末端，避免跨入随后创建的固定 heap。没有扩大修改范围去重写通用空闲区搜索。
选出的 bias 通过现有 ELFParser 同时用于解释器入口和辅助向量 `AT_BASE`。

### 2. 在 MM 边界返回错误，保留内部不变量

位置：[aspace.rs](/home/cuizh/x-kernel/mm/memspace/src/aspace.rs:436)。

```rust
if self.vmas.overlaps(vma.range()) {
    return Err(KError::AlreadyExists);
}
runtime.map(vma.range(), vma.flags(), &mut self.pgtbl.modify())?;
```

检查放在页表修改、object view 注册之前，所以 lazy VMA 即使没有任何 PTE 也能拒绝冲突。
`&mut MmSpace` 保证检查与安装之间的独占访问；没有引入额外锁。
`VmAreaSet::insert` 的内部断言仍保留，用于捕获真正的内部不变量破坏。
对应公开 API rustdoc 及 memspace/kexec 的 design/security 文档已同步。

```mermaid
flowchart LR
    A[主 ELF 映射完成] --> B[计算解释器跨度与最大对齐]
    B --> C[在未来 heap 之前查找空闲区域]
    C --> D{找到可用 bias?}
    D -->|否| E[返回装载错误]
    D -->|是| F[逐段请求 MM 映射]
    F --> G{VMA 重叠?}
    G -->|是| E
    G -->|否| H[建立映射元数据]
    H --> I[设置解释器入口及 AT_BASE]
    I --> J[进入用户态动态链接器]
```

## 测试结果

| 验证 | 实际结果 |
|---|---|
| AArch64 defconfig / make defconfig | 通过；生成配置与保存的原配置相同 |
| make build、make clippy、pinned nightly rustfmt | 通过；离线执行 |
| memspace、kexec 选定 crate 的 QEMU 单元测试 | **64 passed，0 failed，0 ignored** |
| 修复前内核执行 large-pie-interpreter | 复现同一 `vma.rs:961` panic |
| 修复后内核执行相同 harness 用例 | 正常执行，退出码 0 |
| 实际 Chromium + Weston | 越过原装载 panic，进入用户态图形初始化；窗口未通过验收 |

新增单元测试分别覆盖：80 MiB 主映像占用原解释器地址、对齐要求、非法/溢出/无空间输入，
以及 lazy VMA 冲突被拒绝后原映射仍然有效。单元测试日志包含每个用例结果。
单元测试使用快照，未从已丢弃的覆盖层生成 coverage 报告，不声称覆盖率验证通过。

最小集成复现程序 [large-pie.c](large-pie.c) 是动态链接 PIE，含 80 MiB BSS，
磁盘文件很小。它检验能够执行到 main、AT_BASE 不在该 BSS 内，以及 BSS 的零初始化和读写。
修复后实际输出：

```text
large PIE: BSS=[0x12078,0x5012078), AT_BASE=0x5020000
PASS: large dynamic PIE reached main; relocated interpreter and zero-filled BSS work
__EXIT:0__
```

它通过本机 Starry Test Harness 的 `ci-test-iter` 执行，并非只编译或注入。
用例登记、修复前后客体输出、构建日志和补丁均在 [evidence](evidence/) 中。
正常内核已在单元测试构建后恢复，不会让用户下次启动进入单元测试模式。

## 复现命令与含义

以下为 Ubuntu 宿主机命令。交叉编译器已安装，无需下载；不要加 `-static`，因为
本测试需要实际加载动态链接器。

```bash
cd /home/cuizh/x-kernel
/home/cuizh/toolchains/aarch64-linux-musl-cross/bin/aarch64-linux-musl-gcc \
  -O2 -Wall -Wextra -Werror -fPIE -pie \
  docs/experiments/chromium-elf-loader/large-pie.c \
  -o /tmp/large-pie.aarch64
```

`-fPIE -pie` 生成可重定位主程序；`-O2` 开启优化；`-Wall -Wextra -Werror`
开启警告并把警告作为错误；`-o` 指定输出文件。单独编译不会运行该程序。

本机已登记用例的 harness 位于 `/tmp/xkernel-scm-tests/starry-test-harness`。
使用现成构建产物的验证命令（这些 /tmp 目录不是永久安装目录）：

```bash
cd /tmp/xkernel-scm-tests/starry-test-harness
env CARGO_NET_OFFLINE=true STARRY_SKIP_BUILD=1 \
  STARRY_ROOTFS_TEMPLATE='/home/cuizh/Desktop/ICT产教融合/agentos-disk.img' \
  XKERNEL_REMOTE=/tmp/xkernel-chromium-elf/fixed-root \
  STARRY_ACCEL=0 STARRY_VSOCK=off NET=n INPUT=n GRAPHIC=n MEM=2g \
  CASES=large-pie-interpreter make ci-test-iter run ARCH=aarch64
```

`STARRY_SKIP_BUILD=1` 使用已有内核；`XKERNEL_REMOTE` 在本次调用中指向保存预编译内核
及配置的本地目录；模板镜像先复制再注入，原镜像不改。
`CASES` 只跑该回归；关闭网络、输入和图形，因为它只检验 ELF 装载与基本内存行为。
图形验证使用另一个带 virtio-gpu、virtio-rng、键盘和 tablet 的快照 VM，参数与 Python
驱动脚本也保存到了 evidence。

## 限制与后续定位

- 这是确定性的空闲区选址，不是 ASLR；仍受现有固定 heap 布局限制。
- 没有全面修复所有 ELF 溢出、重叠 PT_LOAD、主程序大对齐等验证问题。
- exec 清理原地址空间之后的失败回滚机制未改动；本补丁不承诺失败原子性。
- 本次只验证 AArch64，未宣称其他架构通过。
- 没有可用的默认 Linux 源码树，也尚未收到替代路径，因此没有编造 Linux 源码对照结论；
  本次根因由实际 ELF、x-kernel 调用链和前后复现直接证明。
- 原来 Weston 能显示、simple-shm 能显示，不意味着 Chromium 所需接口都已实现。

客体内 `/tmp/chromium-test.log` 和宿主的 `/tmp/chromium-test.log` 是不同路径。
该客体的 `/tmp` 是运行时文件系统，panic 退出后无法在 Ubuntu 同名目录找到它。
本次自动化在 VM 仍活着时通过串口打印日志，并保存到宿主 evidence，避免证据丢失。


## 实际 Chromium 的后续观察（本次最终状态）

在 2 GiB、4 vCPU、TCG 的独立快照 VM 内，Weston 使用 DRM + Pixman。
启动 Chromium 后分段等待总计约 120 秒，shell 仍响应，Chromium 主进程和 crashpad
进程仍在，没有再次出现原来的内核 panic，但截图仍然只有 Weston 桌面。

日志中已出现 Chromium 自身的 Wayland/GTK 初始化输出，说明动态链接器与主程序已经
开始执行。Weston 明确报告未发现输入设备；Chromium 报告 `No wl_seat object` 和
`gdk_seat_get_keyboard` 断言，还出现 inotify、D-Bus、NETLINK、DRM render node 的
错误或警告。**目前没有证明其中某一条就是不出窗口的直接根因**，也不能据此把所有
警告都当成必须一次性修完的阻塞。

下一步应定位 Chromium 主线程等待的位置，同时检查 Weston 输入发现链路，逐一验证
是否阻塞窗口创建；不要为了绕开日志而继续随意增加启动参数或伪造设备。
现阶段可保留修复并单独提交装载器补丁，浏览器窗口问题另收集运行期证据。

![约两分钟后的快照：Weston 可见，Chromium 窗口尚未出现](evidence/chromium-long-2.png)

测试 VM 已退出，工作镜像未改写。最后补充公开 API 注释后重新 `make build` 成功，
并再次通过 formatter / diff 检查。行为测试使用补充注释前的等价实现；测试内核哈希与
最终正常构建 bundle 分别归档，避免混淆。没有自动创建 Git 提交。
