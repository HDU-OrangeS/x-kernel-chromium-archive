// SPDX-License-Identifier: Apache-2.0
// Copyright 2025 KylinSoft Co., Ltd. <https://www.kylinos.cn/>
// See LICENSES for license details.

//! Process file descriptor syscalls.

use kerrno::{KError, KResult};
use kprocess::PidFd;
use ksignal::{SignalInfo, Signo};
use linux_raw_sys::general::{O_RDWR, SI_USER};
use posix_types::{UserConstPtr, k_siginfo};

use super::make_queue_signal_info;

/// Create a process file descriptor for the specified process.
pub fn sys_pidfd_open(pid: u32, flags: u32) -> KResult<isize> {
    debug!("sys_pidfd_open <= pid: {pid}, flags: {flags}");

    if flags != 0 {
        return Err(KError::InvalidInput);
    }

    let process = kprocess::pidfd::open_target_process(pid)?;
    kprocess::current_resources()
        .add_file(
            PidFd::new_file(&process, O_RDWR, kprocess::current_cred())?,
            true,
        )
        .map(|fd| fd as _)
}

/// Duplicate a file descriptor from another process using its pidfd.
pub fn sys_pidfd_getfd(pidfd: i32, target_fd: i32, flags: u32) -> KResult<isize> {
    debug!("sys_pidfd_getfd <= pidfd: {pidfd}, target_fd: {target_fd}, flags: {flags}");

    let pidfd_file = kprocess::current_resources().get_file(pidfd)?;
    let pidfd = PidFd::from_file(&pidfd_file)?;
    pidfd
        .live_process()?
        .resources()?
        .fd_table()?
        .read()
        .get(target_fd as usize)
        .ok_or(KError::BadFileDescriptor)
        .and_then(|fd| {
            let fd = kprocess::current_resources().add_file(fd.file().clone(), true)?;
            Ok(fd as isize)
        })
}

/// Sends a signal to the process referenced by the pidfd.
///
/// A null `sig` constructs an `SI_USER` payload from the current user thread's
/// process ID and real UID. Signal zero checks existence and permission without
/// queuing a signal. Requires a current user thread and its descriptor table.
///
/// # Errors
///
/// Rejects unsupported flags and invalid signal numbers with `InvalidInput`,
/// disallowed senders with `OperationNotPermitted`, and forwards descriptor,
/// checked user-copy, and target-lifecycle errors.
pub fn sys_pidfd_send_signal(
    pidfd: i32,
    signo: u32,
    sig: UserConstPtr<k_siginfo>,
    flags: u32,
) -> KResult<isize> {
    if flags != 0 {
        return Err(KError::InvalidInput);
    }

    let pidfd_file = kprocess::current_resources().get_file(pidfd)?;
    let pidfd = PidFd::from_file(&pidfd_file)?;
    let process = pidfd.live_process()?;
    let pid = process.pid();

    // Validate before narrowing: e.g. 256 + SIGTERM must not become SIGTERM.
    let parsed_signo = if signo == 0 {
        None
    } else {
        Some(
            u8::try_from(signo)
                .ok()
                .and_then(Signo::from_repr)
                .ok_or(KError::InvalidInput)?,
        )
    };
    let caller = kprocess::current_cred();
    let sender = kprocess::current_user_thread();
    let sig = if sig.is_null() {
        parsed_signo.map(|signo| {
            let mut info = SignalInfo::new_user(signo, SI_USER as _, sender.pid());
            // new_user initializes the payload; SI_USER selects the kill arm.
            info.0
                .__bindgen_anon_1
                .__bindgen_anon_1
                ._sifields
                ._kill
                ._uid = caller.ruid();
            info
        })
    } else {
        // Keep the queued-payload anti-forgery checks separate from nullable
        // pidfd ABI handling; rt_sigqueueinfo still requires its own payload.
        make_queue_signal_info(pid, signo, sig)?
    };

    // Holding a pidfd stabilizes identity; it does not authorize signal delivery.
    // Like other adapters, effective UID zero approximates capabilities here.
    if sender.pid() != pid && !caller.is_privileged() {
        let target = process.credentials_snapshot()?;
        let has_matching_uid = [caller.ruid(), caller.euid()]
            .iter()
            .any(|uid| *uid == target.ruid() || *uid == target.suid());
        let is_session_continue = parsed_signo == Some(Signo::SIGCONT)
            && sender.process().group().session().sid() == process.group().session().sid();
        if !has_matching_uid && !is_session_continue {
            return Err(KError::OperationNotPermitted);
        }
    }
    kprocess::process_signals::send_to_process_ref(process, sig)?;
    Ok(0)
}
